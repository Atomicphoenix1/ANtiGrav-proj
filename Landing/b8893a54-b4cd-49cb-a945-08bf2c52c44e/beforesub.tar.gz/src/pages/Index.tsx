import { useState, useEffect, useRef } from "react";
import { Navbar } from "@/components/Navbar";
import { HeroSection } from "@/components/HeroSection";
import { FloatingAudioController } from "@/components/FloatingAudioController";
import { ProjectsSection } from "@/components/sections/ProjectsSection";
import { SkillsSection } from "@/components/sections/SkillsSection";
import { EducationSection } from "@/components/sections/EducationSection";
import { ExperienceSection } from "@/components/sections/ExperienceSection";
import { ArchiveSection } from "@/components/sections/ArchiveSection";
import { BiosSection } from "@/components/sections/BiosSection";
import { AdminProvider } from "@/context/AdminContext";
import { AdminBanner } from "@/components/admin/AdminBanner";
import { AdminPanel } from "@/components/admin/AdminPanel";
import { AdminShortcutListener } from "@/components/admin/AdminShortcutListener";
import { useAdmin } from "@/context/AdminContext";

const SECTION_MAP = {
  projects: ProjectsSection,
  skills: SkillsSection,
  education: EducationSection,
  experience: ExperienceSection,
  archive: ArchiveSection,
  bios: BiosSection,
} as const;

function AppContent() {
  const [activeTab, setActiveTab] = useState("tab-five");
  const [fadeKey, setFadeKey] = useState(0);
  const prevTabRef = useRef(activeTab);
  const { orderedTabs, isAdmin, getSectionOrder } = useAdmin();

  function handleTabChange(tabId: string) {
    if (tabId === prevTabRef.current) return;
    prevTabRef.current = tabId;
    setFadeKey((k) => k + 1);
    setActiveTab(tabId);
  }

  const currentTab = orderedTabs.find((t) => t.id === activeTab) ?? orderedTabs[0];
  const showHero = currentTab.showHero === true;
  const forceLightTab = currentTab.sectionIds.includes("archive");
  const orderedSectionIds = getSectionOrder(currentTab.id, currentTab.sectionIds as string[]) as Array<keyof typeof SECTION_MAP>;

  const lightTabStyle: React.CSSProperties = forceLightTab
    ? {
        ["--background" as string]: "oklch(1 0 0)",
        ["--foreground" as string]: "oklch(0.145 0 0)",
        ["--card" as string]: "oklch(1 0 0)",
        ["--card-foreground" as string]: "oklch(0.145 0 0)",
        ["--border" as string]: "oklch(0.922 0 0)",
        ["--muted" as string]: "oklch(0.97 0 0)",
        ["--muted-foreground" as string]: "oklch(0.556 0 0)",
        ["--secondary" as string]: "oklch(0.97 0 0)",
        ["--secondary-foreground" as string]: "oklch(0.205 0 0)",
        background: "oklch(1 0 0)",
        color: "oklch(0.145 0 0)",
        colorScheme: "light",
      }
    : {};

  return (
    <div className="min-h-dvh bg-background text-foreground" style={{ paddingTop: isAdmin ? "38px" : undefined }}>
      <AdminBanner />
      <Navbar activeTab={activeTab} onTabChange={handleTabChange} />

      <main>
        {showHero ? (
          <>
            <HeroSection />
            <div className="border-t border-border/40">
              <div className="mx-auto max-w-7xl px-6 py-12 sm:py-16">
                <div
                  key={fadeKey}
                  role="tabpanel"
                  aria-label={currentTab.label}
                  className="flex flex-col gap-16 tab-fade-in"
                >
                  {orderedSectionIds.map((sectionId) => {
                    const Section = SECTION_MAP[sectionId];
                    return <Section key={sectionId} />;
                  })}
                </div>
              </div>
            </div>
          </>
        ) : (
          <div
            key={fadeKey}
            role="tabpanel"
            aria-label={currentTab.label}
            className="flex flex-col gap-16 py-12 sm:py-16 tab-fade-in"
            style={lightTabStyle}
          >
            {orderedSectionIds.length === 0 ? (
              <div className="flex flex-col items-center justify-center gap-3 py-24 text-center">
                <p className="font-heading text-xl font-semibold text-foreground">
                  {currentTab.label}
                </p>
                <p className="text-sm text-muted-foreground">
                  Content coming soon — add sections in{" "}
                  <code className="rounded bg-secondary px-1.5 py-0.5 text-xs font-mono">
                    src/data/portfolioData.ts
                  </code>
                </p>
              </div>
            ) : (
              orderedSectionIds.map((sectionId) => {
                const Section = SECTION_MAP[sectionId];
                return <Section key={sectionId} />;
              })
            )}
          </div>
        )}
      </main>

      <footer className="border-t border-border/40 py-8 text-center text-xs text-muted-foreground">
        <p>
          © {new Date().getFullYear()} Seif Rabie Sakr · Built with love &amp; science
        </p>
      </footer>

      <FloatingAudioController />
      <AdminPanel />
      <AdminShortcutListener />
    </div>
  );
}

export default function Index() {
  return (
    <AdminProvider>
      <AppContent />
    </AdminProvider>
  );
}
