import { useState } from "react";
import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  ResponsiveContainer,
  Tooltip,
} from "recharts";
import { skills } from "@/data/portfolioData";
import { useAdmin } from "@/context/AdminContext";
import { useIntersectionObserver } from "@/hooks/useIntersectionObserver";
import { FadeInSection } from "@/components/FadeInSection";

const RADAR_COLORS = ["#7DF9A4", "#C77DFF", "#4CC9F0", "#FFD166", "#FF6B6B"];

function buildRadarData(groups: typeof skills) {
  return groups.map((g) => ({
    subject: g.category.length > 18 ? g.category.slice(0, 16) + "…" : g.category,
    fullName: g.category,
    score: Math.min(100, 55 + g.items.length * 7),
  }));
}

function SkillsRadar({ groups }: { groups: typeof skills }) {
  const { ref, visible } = useIntersectionObserver(0.2);
  const data = buildRadarData(groups);

  return (
    <div ref={ref} className="h-72 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart data={data} margin={{ top: 10, right: 30, bottom: 10, left: 30 }}>
          <PolarGrid stroke="hsl(var(--border))" />
          <PolarAngleAxis
            dataKey="subject"
            tick={{ fontSize: 10, fontFamily: "var(--font-mono)", fill: "hsl(var(--muted-foreground))" }}
          />
          <Tooltip
            formatter={(value: number, _name: string, props: { payload?: { fullName?: string } }) => [
              `${value}`,
              props.payload?.fullName ?? "",
            ]}
            contentStyle={{
              background: "hsl(var(--card))",
              border: "2px solid hsl(var(--border))",
              borderRadius: "8px",
              fontFamily: "var(--font-mono)",
              fontSize: "11px",
            }}
          />
          <Radar
            dataKey="score"
            stroke="#7DF9A4"
            fill="#7DF9A4"
            fillOpacity={0.25}
            strokeWidth={2}
            isAnimationActive={visible}
            animationDuration={900}
            animationEasing="ease-out"
          />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function SkillsSection() {
  const { getBlockOrder } = useAdmin();
  const defaultIds = skills.map((g) => g.category);
  const orderedIds = getBlockOrder("skills", defaultIds);
  const orderedSkills = orderedIds
    .map((id) => skills.find((g) => g.category === id))
    .filter(Boolean) as typeof skills;

  const [view, setView] = useState<"chart" | "list">("chart");

  return (
    <section aria-labelledby="skills-heading">
      <FadeInSection>
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
          <h2
            id="skills-heading"
            className="font-heading text-2xl font-bold tracking-tight text-foreground"
          >
            Technical Skills & Core Competencies
          </h2>
          <div className="flex overflow-hidden rounded-lg border-2 border-border">
            {(["chart", "list"] as const).map((v) => (
              <button
                key={v}
                onClick={() => setView(v)}
                className={[
                  "px-3 py-1.5 font-mono text-[10px] font-bold uppercase tracking-widest transition-colors",
                  view === v
                    ? "bg-foreground text-background"
                    : "bg-card text-muted-foreground hover:text-foreground",
                ].join(" ")}
              >
                {v}
              </button>
            ))}
          </div>
        </div>
      </FadeInSection>

      {view === "chart" ? (
        <FadeInSection delay={80}>
          <div
            className="rounded-2xl border-2 border-border bg-card p-6"
            style={{ boxShadow: "4px 4px 0 0 hsl(var(--border) / 1)" }}
          >
            <SkillsRadar groups={orderedSkills} />
            <div className="mt-4 flex flex-wrap justify-center gap-3">
              {orderedSkills.map((g, i) => (
                <span
                  key={g.category}
                  className="flex items-center gap-1.5 font-mono text-[10px] text-muted-foreground"
                >
                  <span
                    className="h-2 w-2 rounded-full"
                    style={{ background: RADAR_COLORS[i % RADAR_COLORS.length] }}
                  />
                  {g.category}
                </span>
              ))}
            </div>
          </div>
        </FadeInSection>
      ) : (
        <div className="grid gap-6 sm:grid-cols-2">
          {orderedSkills.map((group, i) => (
            <FadeInSection key={group.category} delay={i * 60}>
              <div className="rounded-2xl border border-border bg-card p-6">
                <h3
                  className="mb-4 text-xs font-semibold uppercase tracking-[0.15em]"
                  style={{ color: RADAR_COLORS[i % RADAR_COLORS.length] }}
                >
                  {group.category}
                </h3>
                <ul className="flex flex-col gap-2.5">
                  {group.items.map((item) => (
                    <li key={item} className="flex items-start gap-2 text-sm text-card-foreground">
                      <span
                        className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full"
                        style={{ background: RADAR_COLORS[i % RADAR_COLORS.length] }}
                        aria-hidden="true"
                      />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </FadeInSection>
          ))}
        </div>
      )}
    </section>
  );
}
