import { Zap } from "lucide-react";
import { projects } from "@/data/portfolioData";
import { ProjectCard } from "@/components/ProjectCard";
import { useAdmin } from "@/context/AdminContext";

const ACCENT_COLORS = ["#7DF9A4", "#FFD166", "#4CC9F0"];

export function ProjectsSection() {
  const { getBlockOrder } = useAdmin();
  const defaultIds = projects.map((p) => p.id);
  const orderedIds = getBlockOrder("projects", defaultIds);
  const orderedProjects = orderedIds.map((id) => projects.find((p) => p.id === id)).filter(Boolean) as typeof projects;

  return (
    <section aria-labelledby="projects-heading" className="mx-auto max-w-7xl px-6">

      {/* ── Hero header ──────────────────────────────────────────────── */}
      <div className="mb-12 flex flex-col gap-6 border-b-2 border-border pb-10">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <div className="mb-3 flex items-center gap-2">
              <span
                className="flex h-8 w-8 items-center justify-center rounded-lg border-2 border-border"
                style={{ background: "#7DF9A4" }}
              >
                <Zap className="h-4 w-4 text-black" aria-hidden="true" />
              </span>
              <span className="font-mono text-xs font-bold uppercase tracking-widest text-muted-foreground">
                Selected Work
              </span>
            </div>
            <h2
              id="projects-heading"
              className="font-heading text-5xl font-black uppercase leading-none tracking-tight text-foreground sm:text-6xl"
              style={{ letterSpacing: "-0.03em" }}
            >
              Projects
            </h2>
          </div>

          {/* Project count badge */}
          <div
            className="shrink-0 rounded-2xl border-2 border-border bg-card px-5 py-3 text-center"
            style={{ boxShadow: "4px 4px 0 0 hsl(var(--border) / 1)" }}
          >
            <p className="font-mono text-3xl font-black leading-none text-foreground">
              0{projects.length}
            </p>
            <p className="mt-0.5 font-heading text-[10px] font-black uppercase tracking-widest text-muted-foreground">
              Projects
            </p>
          </div>
        </div>

        <p className="max-w-2xl font-body text-sm leading-relaxed text-muted-foreground">
          End-to-end builds at the intersection of AI automation, computational science, and education.
          Each card includes an audio story — hit play to hear the thinking behind the work.
        </p>

        {/* Domain tags */}
        <div className="flex flex-wrap gap-2">
          {["AI Automation", "Computational Chemistry", "STEM Education", "n8n Workflows", "Python"].map((tag, i) => (
            <span
              key={tag}
              className="rounded border-2 border-border px-2.5 py-1 font-body text-xs font-semibold text-foreground"
              style={{ background: ACCENT_COLORS[i % ACCENT_COLORS.length] + "30" }}
            >
              {tag}
            </span>
          ))}
        </div>
      </div>

      {/* ── Project grid ─────────────────────────────────────────────── */}
      <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3" role="list">
        {orderedProjects.map((project) => (
          <li key={project.id}>
            <ProjectCard project={project} />
          </li>
        ))}
      </ul>
    </section>
  );
}
