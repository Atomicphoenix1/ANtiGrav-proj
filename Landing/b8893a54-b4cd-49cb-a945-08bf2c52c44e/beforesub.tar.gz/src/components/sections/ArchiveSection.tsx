import { useState, useRef, useCallback, useId } from "react";
import {
  FileText, Code2, FlaskConical, GraduationCap, Award, BookOpen,
  Folder, FolderOpen, X, Plus, Upload, File, Film, Music,
  Image, Archive, Presentation,
} from "lucide-react";
import { archiveFolders as STATIC_FOLDERS } from "@/data/archiveData";

// ── Types ──────────────────────────────────────────────────────────────────────

interface StoredFile {
  id: string;
  name: string;
  mimeType: string;
  sizeBytes: number;
  uploadedAt: string;
  /** In-session object URL — not persisted, recreated on upload */
  objectUrl?: string;
}

interface DynamicFolder {
  id: string;
  label: string;
  bgColor: string;
  files: StoredFile[];
}

interface ArchiveStore {
  v: 1;
  folders: DynamicFolder[];
}

const STORE_KEY = "archive-store-v1";
const FOLDER_COLORS = ["#7DF9A4", "#FFD166", "#C77DFF", "#FF6B6B", "#4CC9F0", "#F4A261", "#E0C3FC", "#FFC8DD"];

// ── LocalStorage helpers (client-localstorage-schema rule: versioned) ──────────

function loadStore(): ArchiveStore {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (!raw) return { v: 1, folders: [] };
    const parsed = JSON.parse(raw) as ArchiveStore;
    if (parsed.v !== 1) return { v: 1, folders: [] };
    return parsed;
  } catch {
    return { v: 1, folders: [] };
  }
}

function saveStore(store: ArchiveStore) {
  try {
    localStorage.setItem(STORE_KEY, JSON.stringify(store));
  } catch {
    // localStorage may be unavailable — fail silently
  }
}

// ── File type → icon + colour ──────────────────────────────────────────────────

function fileIcon(mimeType: string): { Icon: React.ElementType; color: string } {
  if (mimeType.startsWith("image/")) return { Icon: Image, color: "#FFD166" };
  if (mimeType.startsWith("video/")) return { Icon: Film, color: "#FF6B6B" };
  if (mimeType.startsWith("audio/")) return { Icon: Music, color: "#C77DFF" };
  if (mimeType === "application/pdf") return { Icon: FileText, color: "#F4A261" };
  if (mimeType.includes("word") || mimeType.includes("document")) return { Icon: FileText, color: "#4CC9F0" };
  if (mimeType.includes("presentation") || mimeType.includes("powerpoint")) return { Icon: Presentation, color: "#FF6B6B" };
  if (mimeType.includes("spreadsheet") || mimeType.includes("excel")) return { Icon: FileText, color: "#7DF9A4" };
  if (mimeType.includes("zip") || mimeType.includes("archive") || mimeType.includes("tar")) return { Icon: Archive, color: "#E0C3FC" };
  if (mimeType.includes("javascript") || mimeType.includes("typescript") || mimeType.includes("python") || mimeType.includes("text/x-")) return { Icon: Code2, color: "#7DF9A4" };
  if (mimeType.startsWith("text/")) return { Icon: FileText, color: "#4CC9F0" };
  return { Icon: File, color: "#FFD166" };
}

function staticFileIcon(type: string): { Icon: React.ElementType; color: string } {
  const map: Record<string, { Icon: React.ElementType; color: string }> = {
    report: { Icon: FileText, color: "#FFD166" },
    code: { Icon: Code2, color: "#7DF9A4" },
    research: { Icon: FlaskConical, color: "#C77DFF" },
    teaching: { Icon: GraduationCap, color: "#FF6B6B" },
    certificate: { Icon: Award, color: "#F4A261" },
    publication: { Icon: BookOpen, color: "#4CC9F0" },
    notebook: { Icon: BookOpen, color: "#4CC9F0" },
    presentation: { Icon: Presentation, color: "#C77DFF" },
  };
  return map[type] ?? { Icon: File, color: "#FFD166" };
}

function formatSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

// ── Sub-components ─────────────────────────────────────────────────────────────

function StaticFileRow({ file }: { file: { id: string; name: string; type: string; year: string; description?: string } }) {
  const { Icon, color } = staticFileIcon(file.type);
  return (
    <li className="flex items-start gap-3 rounded-lg border-2 border-black bg-white px-3 py-2.5"
      style={{ boxShadow: "2px 2px 0 0 #000" }}>
      <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded border-2 border-black" style={{ background: color }}>
        <Icon className="h-3 w-3 text-black" aria-hidden="true" />
      </span>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-semibold leading-tight text-black font-heading">{file.name}</p>
        {file.description && <p className="mt-0.5 text-xs leading-relaxed text-neutral-600 font-body">{file.description}</p>}
      </div>
      <span className="shrink-0 rounded border border-black bg-black px-1.5 py-0.5 font-mono text-[10px] font-bold text-white">{file.year}</span>
    </li>
  );
}

function DynamicFileRow({ file, onDelete }: { file: StoredFile; onDelete: () => void }) {
  const { Icon, color } = fileIcon(file.mimeType);
  return (
    <li className="group flex items-start gap-3 rounded-lg border-2 border-black bg-white px-3 py-2.5" style={{ boxShadow: "2px 2px 0 0 #000" }}>
      <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded border-2 border-black" style={{ background: color }}>
        <Icon className="h-3 w-3 text-black" aria-hidden="true" />
      </span>
      <div className="min-w-0 flex-1">
        {file.objectUrl ? (
          <a
            href={file.objectUrl}
            target="_blank"
            rel="noreferrer"
            download={file.name}
            className="truncate text-sm font-semibold leading-tight text-black font-heading underline-offset-2 hover:underline"
          >
            {file.name}
          </a>
        ) : (
          <p className="truncate text-sm font-semibold leading-tight text-black font-heading">{file.name}</p>
        )}
        <p className="mt-0.5 text-[10px] text-neutral-500 font-mono">{formatSize(file.sizeBytes)} · {new Date(file.uploadedAt).toLocaleDateString()}</p>
      </div>
      <button
        onClick={onDelete}
        aria-label={`Delete ${file.name}`}
        className="cursor-pointer opacity-0 group-hover:opacity-100 transition-opacity rounded border border-black p-0.5 text-black hover:bg-red-100"
      >
        <X className="h-3 w-3" aria-hidden="true" />
      </button>
    </li>
  );
}

// ── Create Folder Modal ────────────────────────────────────────────────────────

interface CreateFolderModalProps {
  onConfirm: (label: string, bgColor: string) => void;
  onClose: () => void;
}

function CreateFolderModal({ onConfirm, onClose }: CreateFolderModalProps) {
  const [label, setLabel] = useState("");
  const [selectedColor, setSelectedColor] = useState(FOLDER_COLORS[0]);
  const inputId = useId();

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === "Escape") onClose();
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (label.trim()) onConfirm(label.trim(), selectedColor);
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Create new folder"
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      onKeyDown={handleKeyDown}
    >
      <button
        className="absolute inset-0 bg-black/60 backdrop-blur-sm cursor-default"
        onClick={onClose}
        aria-label="Close modal"
        tabIndex={-1}
      />
      <div
        className="relative z-10 w-full max-w-sm rounded-2xl border-2 border-black bg-white p-6"
        style={{ boxShadow: "8px 8px 0 0 #000" }}
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-heading text-lg font-black uppercase tracking-tight text-black">New Folder</h2>
          <button onClick={onClose} aria-label="Close" className="cursor-pointer rounded-full border-2 border-black p-1 hover:bg-black hover:text-white transition-colors">
            <X className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div>
            <label htmlFor={inputId} className="mb-1.5 block font-heading text-xs font-black uppercase tracking-widest text-black">
              Folder Name
            </label>
            <input
              id={inputId}
              type="text"
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              placeholder="e.g. Thesis, Patents…"
              className="w-full rounded-xl border-2 border-black px-3 py-2.5 font-body text-sm text-black placeholder-neutral-400 outline-none focus:ring-2 focus:ring-black"
              autoFocus
            />
          </div>
          <div>
            <p className="mb-2 font-heading text-xs font-black uppercase tracking-widest text-black">Color</p>
            <div className="flex flex-wrap gap-2">
              {FOLDER_COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setSelectedColor(c)}
                  aria-label={`Select color ${c}`}
                  aria-pressed={selectedColor === c}
                  className="h-8 w-8 cursor-pointer rounded-lg border-2 transition-transform hover:scale-110"
                  style={{
                    background: c,
                    borderColor: selectedColor === c ? "#000" : "transparent",
                    boxShadow: selectedColor === c ? "2px 2px 0 0 #000" : "none",
                  }}
                />
              ))}
            </div>
          </div>
          <button
            type="submit"
            disabled={!label.trim()}
            className="cursor-pointer rounded-xl border-2 border-black bg-black py-2.5 font-heading text-sm font-black uppercase tracking-widest text-white transition-opacity hover:opacity-80 disabled:cursor-not-allowed disabled:opacity-40"
          >
            Create Folder
          </button>
        </form>
      </div>
    </div>
  );
}

// ── Main Section ───────────────────────────────────────────────────────────────

export function ArchiveSection() {
  const [openId, setOpenId] = useState<string | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [isDragOver, setIsDragOver] = useState(false);

  // Lazy init from localStorage (rerender-lazy-state-init rule)
  const [dynStore, setDynStore] = useState<ArchiveStore>(() => loadStore());

  const fileInputRef = useRef<HTMLInputElement>(null);

  const allFolders = dynStore.folders;

  // Persist on every change
  function updateStore(updater: (prev: ArchiveStore) => ArchiveStore) {
    setDynStore((prev) => {
      const next = updater(prev);
      saveStore(next);
      return next;
    });
  }

  function createFolder(label: string, bgColor: string) {
    const id = `dyn-${Date.now()}`;
    updateStore((s) => ({ ...s, folders: [...s.folders, { id, label, bgColor, files: [] }] }));
    setShowCreateModal(false);
    setOpenId(id);
  }

  function deleteFolder(folderId: string) {
    updateStore((s) => ({ ...s, folders: s.folders.filter((f) => f.id !== folderId) }));
    if (openId === folderId) setOpenId(null);
  }

  const addFilesToFolder = useCallback((folderId: string, incoming: File[]) => {
    updateStore((s) => {
      const folders = s.folders.map((f) => {
        if (f.id !== folderId) return f;
        const newFiles: StoredFile[] = incoming.map((file) => ({
          id: `file-${Date.now()}-${Math.random().toString(36).slice(2)}`,
          name: file.name,
          mimeType: file.type || "application/octet-stream",
          sizeBytes: file.size,
          uploadedAt: new Date().toISOString(),
          objectUrl: URL.createObjectURL(file),
        }));
        return { ...f, files: [...f.files, ...newFiles] };
      });
      return { ...s, folders };
    });
  }, []);

  function deleteFile(folderId: string, fileId: string) {
    updateStore((s) => ({
      ...s,
      folders: s.folders.map((f) =>
        f.id !== folderId ? f : { ...f, files: f.files.filter((fi) => fi.id !== fileId) }
      ),
    }));
  }

  // Determine what folder is open (static or dynamic)
  const openStaticFolder = STATIC_FOLDERS.find((f) => f.id === openId);
  const openDynFolder = allFolders.find((f) => f.id === openId);

  // ── File drop zone for open dynamic folder ─────────────────────────────────
  function handleDragOver(e: React.DragEvent) {
    e.preventDefault();
    setIsDragOver(true);
  }
  function handleDragLeave() {
    setIsDragOver(false);
  }
  function handleDrop(e: React.DragEvent) {
    e.preventDefault();
    setIsDragOver(false);
    if (!openDynFolder) return;
    const files = Array.from(e.dataTransfer.files);
    if (files.length) addFilesToFolder(openDynFolder.id, files);
  }
  function handleFileInput(e: React.ChangeEvent<HTMLInputElement>) {
    if (!openDynFolder || !e.target.files) return;
    addFilesToFolder(openDynFolder.id, Array.from(e.target.files));
    e.target.value = "";
  }

  return (
    <section aria-labelledby="archive-heading" className="mx-auto max-w-7xl px-6">
      {/* Header */}
      <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2
            id="archive-heading"
            className="font-heading text-3xl font-black uppercase tracking-tight text-foreground"
            style={{ letterSpacing: "-0.02em" }}
          >
            Career Archive
          </h2>
          <p className="mt-1 font-body text-sm text-muted-foreground">
            Every project, report, and material — organized by category.
          </p>
        </div>
        <button
          onClick={() => setShowCreateModal(true)}
          className="flex cursor-pointer items-center gap-2 rounded-xl border-2 border-black bg-black px-4 py-2 font-heading text-xs font-black uppercase tracking-widest text-white transition-opacity hover:opacity-75"
          style={{ boxShadow: "3px 3px 0 0 #555" }}
        >
          <Plus className="h-4 w-4" aria-hidden="true" />
          New Folder
        </button>
      </div>

      {/* ── Static folders ─────────────────────────────────────────────────── */}
      <div className="mb-6">
        <p className="mb-3 font-heading text-[10px] font-black uppercase tracking-widest text-muted-foreground">
          Built-in
        </p>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
          {STATIC_FOLDERS.map((folder) => {
            const isOpen = openId === folder.id;
            return (
              <button
                key={folder.id}
                onClick={() => setOpenId(isOpen ? null : folder.id)}
                aria-pressed={isOpen}
                aria-label={`${isOpen ? "Close" : "Open"} ${folder.label} folder`}
                className="group flex flex-col items-center gap-2 rounded-none border-none bg-transparent p-0 text-center focus-visible:outline-2 focus-visible:outline-black cursor-pointer"
              >
                <div
                  className="relative flex h-20 w-full items-center justify-center rounded-xl border-2 border-black transition-transform duration-150 group-hover:-translate-y-1 group-active:translate-y-0"
                  style={{
                    background: folder.bgColor,
                    boxShadow: isOpen ? "2px 2px 0 0 #000" : "4px 4px 0 0 #000",
                    color: folder.textColor,
                  }}
                >
                  {isOpen ? <FolderOpen className="h-9 w-9" aria-hidden="true" /> : <Folder className="h-9 w-9" aria-hidden="true" />}
                  <span className="absolute -right-2 -top-2 flex h-5 w-5 items-center justify-center rounded-full border-2 border-black bg-black font-mono text-[9px] font-black text-white">
                    {folder.files.length}
                  </span>
                </div>
                <span className="font-heading text-xs font-black uppercase tracking-tight text-foreground">
                  {folder.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* ── Dynamic (user-created) folders ─────────────────────────────────── */}
      {allFolders.length > 0 && (
        <div className="mb-6">
          <p className="mb-3 font-heading text-[10px] font-black uppercase tracking-widest text-muted-foreground">
            My Folders
          </p>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
            {allFolders.map((folder) => {
              const isOpen = openId === folder.id;
              return (
                <div key={folder.id} className="relative">
                  <button
                    onClick={() => setOpenId(isOpen ? null : folder.id)}
                    aria-pressed={isOpen}
                    aria-label={`${isOpen ? "Close" : "Open"} ${folder.label} folder`}
                    className="group flex w-full flex-col items-center gap-2 rounded-none border-none bg-transparent p-0 text-center focus-visible:outline-2 focus-visible:outline-black cursor-pointer"
                  >
                    <div
                      className="relative flex h-20 w-full items-center justify-center rounded-xl border-2 border-black transition-transform duration-150 group-hover:-translate-y-1 group-active:translate-y-0"
                      style={{
                        background: folder.bgColor,
                        boxShadow: isOpen ? "2px 2px 0 0 #000" : "4px 4px 0 0 #000",
                      }}
                    >
                      {isOpen ? <FolderOpen className="h-9 w-9 text-black" aria-hidden="true" /> : <Folder className="h-9 w-9 text-black" aria-hidden="true" />}
                      <span className="absolute -right-2 -top-2 flex h-5 w-5 items-center justify-center rounded-full border-2 border-black bg-black font-mono text-[9px] font-black text-white">
                        {folder.files.length}
                      </span>
                    </div>
                    <span className="font-heading text-xs font-black uppercase tracking-tight text-foreground">
                      {folder.label}
                    </span>
                  </button>
                  {/* Delete folder */}
                  <button
                    onClick={() => deleteFolder(folder.id)}
                    aria-label={`Delete ${folder.label} folder`}
                    className="absolute -top-1 -left-1 z-10 flex h-5 w-5 cursor-pointer items-center justify-center rounded-full border-2 border-black bg-white text-black opacity-0 transition-opacity hover:bg-red-100 group-hover:opacity-100 focus:opacity-100"
                    style={{ boxShadow: "1px 1px 0 0 #000" }}
                  >
                    <X className="h-2.5 w-2.5" aria-hidden="true" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ── Expanded static folder panel ───────────────────────────────────── */}
      {openStaticFolder && (
        <div
          className="mt-4 rounded-2xl border-2 border-black"
          style={{ background: openStaticFolder.bgColor + "22", boxShadow: "6px 6px 0 0 #000" }}
        >
          <div
            className="flex items-center justify-between rounded-t-xl border-b-2 border-black px-5 py-3"
            style={{ background: openStaticFolder.bgColor }}
          >
            <div className="flex items-center gap-2">
              <h3 className="font-heading text-base font-black uppercase tracking-tight" style={{ color: openStaticFolder.textColor }}>
                {openStaticFolder.label}
              </h3>
              <span className="rounded border border-black bg-black px-1.5 py-0.5 font-mono text-[10px] font-bold text-white">
                {openStaticFolder.files.length} files
              </span>
            </div>
            <button onClick={() => setOpenId(null)} aria-label="Close folder" className="flex h-6 w-6 cursor-pointer items-center justify-center rounded-full border-2 border-black bg-white transition-opacity hover:opacity-70">
              <X className="h-3 w-3 text-black" aria-hidden="true" />
            </button>
          </div>
          <ul className="grid gap-2 p-5 sm:grid-cols-2 lg:grid-cols-3">
            {openStaticFolder.files.map((file) => (
              <StaticFileRow key={file.id} file={file} />
            ))}
          </ul>
        </div>
      )}

      {/* ── Expanded dynamic folder panel with upload ───────────────────────── */}
      {openDynFolder && (
        <div
          className="mt-4 rounded-2xl border-2 border-black"
          style={{ background: openDynFolder.bgColor + "22", boxShadow: "6px 6px 0 0 #000" }}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          {/* Panel header */}
          <div
            className="flex items-center justify-between rounded-t-xl border-b-2 border-black px-5 py-3"
            style={{ background: openDynFolder.bgColor }}
          >
            <div className="flex items-center gap-2">
              <h3 className="font-heading text-base font-black uppercase tracking-tight text-black">
                {openDynFolder.label}
              </h3>
              <span className="rounded border border-black bg-black px-1.5 py-0.5 font-mono text-[10px] font-bold text-white">
                {openDynFolder.files.length} files
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => fileInputRef.current?.click()}
                aria-label="Upload files"
                className="flex cursor-pointer items-center gap-1.5 rounded-lg border-2 border-black bg-black px-3 py-1 font-heading text-[10px] font-black uppercase tracking-widest text-white transition-opacity hover:opacity-75"
              >
                <Upload className="h-3 w-3" aria-hidden="true" />
                Upload
              </button>
              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept="*/*"
                className="hidden"
                onChange={handleFileInput}
                aria-label="Upload files to this folder"
              />
              <button onClick={() => setOpenId(null)} aria-label="Close folder" className="flex h-6 w-6 cursor-pointer items-center justify-center rounded-full border-2 border-black bg-white transition-opacity hover:opacity-70">
                <X className="h-3 w-3 text-black" aria-hidden="true" />
              </button>
            </div>
          </div>

          {/* Drag-and-drop zone + file list */}
          <div className="p-5">
            {isDragOver && (
              <div className="mb-4 flex h-20 items-center justify-center rounded-xl border-2 border-dashed border-black bg-black/10">
                <p className="font-heading text-sm font-black uppercase tracking-widest text-black">
                  Drop files here
                </p>
              </div>
            )}

            {openDynFolder.files.length === 0 && !isDragOver ? (
              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex w-full cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-black py-10 text-center transition-colors hover:bg-black/5"
              >
                <Upload className="h-7 w-7 text-black/40" aria-hidden="true" />
                <p className="font-heading text-sm font-black uppercase tracking-widest text-black/60">
                  Upload files or drag &amp; drop
                </p>
                <p className="font-body text-xs text-black/40">
                  PDFs, Docs, PPTX, Images, Videos, Code — any format
                </p>
              </button>
            ) : (
              <ul className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                {openDynFolder.files.map((file) => (
                  <DynamicFileRow
                    key={file.id}
                    file={file}
                    onDelete={() => deleteFile(openDynFolder.id, file.id)}
                  />
                ))}
              </ul>
            )}
          </div>
        </div>
      )}

      {/* ── Create Folder Modal ─────────────────────────────────────────────── */}
      {showCreateModal && (
        <CreateFolderModal
          onConfirm={createFolder}
          onClose={() => setShowCreateModal(false)}
        />
      )}
    </section>
  );
}
