import { Mail, Phone, MapPin, Github, GraduationCap, Briefcase, Star, FlaskConical, BookOpen } from "lucide-react";
import { personal, education, experience, skills } from "@/data/portfolioData";
import { useAdmin } from "@/context/AdminContext";
import type { SocialLink } from "@/data/portfolioData";

const ICON_MAP: Record<SocialLink["icon"], typeof Mail> = {
  email: Mail,
  phone: Phone,
  location: MapPin,
  github: Github,
};

const CREDENTIAL_COLORS = ["#7DF9A4", "#FFD166", "#C77DFF", "#4CC9F0", "#FF6B6B", "#F4A261"];
const SHADOW = "6px 6px 0 0 hsl(var(--border) / 1)";

const DEFAULT_BLOCK_ORDER = [
  "identity",
  "education-card",
  "contact",
  "experience-card",
  "skills-panel",
  "research",
  "academic",
];

// ── Individual card components ────────────────────────────────────────────────

function IdentityCard() {
  return (
    <div className="rounded-2xl border-2 border-border bg-card p-6" style={{ boxShadow: SHADOW }}>
      <div
        className="mb-4 flex h-16 w-16 items-center justify-center rounded-xl border-2 border-border text-3xl font-black text-black"
        style={{ background: "#7DF9A4", boxShadow: "3px 3px 0 0 hsl(var(--border) / 1)" }}
        aria-hidden="true"
      >
        S
      </div>
      <h2 id="bios-heading" className="font-heading text-2xl font-black uppercase tracking-tight text-card-foreground">
        {personal.name}
      </h2>
      <p className="mt-1 font-body text-sm font-semibold text-muted-foreground uppercase tracking-widest">
        {personal.title}
      </p>
      <p className="mt-3 font-body text-sm leading-relaxed text-muted-foreground">
        {personal.tagline}
      </p>
    </div>
  );
}

function ContactCard() {
  return (
    <div className="rounded-2xl border-2 border-border bg-card p-6" style={{ boxShadow: SHADOW }}>
      <h3 className="mb-4 font-heading text-xs font-black uppercase tracking-widest text-card-foreground">
        Contact & Links
      </h3>
      <ul className="flex flex-col gap-2.5">
        {personal.socials.map((s, i) => {
          const Icon = ICON_MAP[s.icon];
          const color = CREDENTIAL_COLORS[i % CREDENTIAL_COLORS.length];
          return (
            <li key={s.label}>
              <a
                href={s.url}
                target={s.url.startsWith("http") ? "_blank" : undefined}
                rel={s.url.startsWith("http") ? "noreferrer" : undefined}
                className="group flex items-center gap-3 rounded-lg border-2 border-border p-2.5 transition-all hover:-translate-y-px hover:shadow-md"
                style={{ background: color + "20" }}
              >
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md border-2 border-border" style={{ background: color }}>
                  <Icon className="h-3.5 w-3.5 text-black" aria-hidden="true" />
                </span>
                <span className="font-body text-xs font-medium text-card-foreground truncate">{s.label}</span>
              </a>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function SkillsPanelCard() {
  return (
    <div className="rounded-2xl border-2 border-border p-6" style={{ background: "#4CC9F0", boxShadow: SHADOW }}>
      <h3 className="mb-4 font-heading text-xs font-black uppercase tracking-widest text-black">Core Skills</h3>
      <div className="flex flex-col gap-3">
        {skills.map((group) => (
          <div key={group.category}>
            <p className="mb-1.5 font-heading text-[10px] font-black uppercase tracking-wider text-black/60">
              {group.category}
            </p>
            <div className="flex flex-wrap gap-1.5">
              {group.items.map((item) => (
                <span key={item} className="rounded border-2 border-black bg-white px-2 py-0.5 font-body text-[10px] font-semibold text-black">
                  {item}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function EducationCard() {
  const edu = education[0];
  if (!edu) return null;
  return (
    <div className="rounded-2xl border-2 border-border bg-card p-6" style={{ boxShadow: SHADOW }}>
      <div className="mb-4 flex items-center gap-2">
        <span className="flex h-8 w-8 items-center justify-center rounded-lg border-2 border-border" style={{ background: "#FFD166" }}>
          <GraduationCap className="h-4 w-4 text-black" aria-hidden="true" />
        </span>
        <h3 className="font-heading text-xs font-black uppercase tracking-widest text-card-foreground">Education</h3>
      </div>
      <p className="font-heading text-lg font-black leading-tight text-card-foreground">{edu.degree}</p>
      {edu.concentration && (
        <p className="mt-0.5 font-body text-sm font-semibold text-muted-foreground">Concentration: {edu.concentration}</p>
      )}
      <p className="mt-1 font-body text-sm text-muted-foreground">{edu.institution}</p>
      <div className="mt-2 flex flex-wrap gap-2">
        <span className="rounded border-2 border-border bg-foreground px-2 py-0.5 font-mono text-[10px] font-bold text-background">{edu.period}</span>
        <span className="rounded border-2 border-border bg-foreground px-2 py-0.5 font-mono text-[10px] font-bold text-background">{edu.status}</span>
        {edu.gpa && (
          <span className="rounded border-2 border-border px-2 py-0.5 font-mono text-[10px] font-bold text-black" style={{ background: "#7DF9A4" }}>
            GPA {edu.gpa}
          </span>
        )}
      </div>
      {edu.honors && edu.honors.length > 0 && (
        <div className="mt-4">
          <p className="mb-1.5 font-heading text-[10px] font-black uppercase tracking-wider text-muted-foreground">Honors</p>
          <ul className="flex flex-col gap-1">
            {edu.honors.map((h) => (
              <li key={h} className="flex items-center gap-2 font-body text-xs text-muted-foreground">
                <Star className="h-3 w-3 shrink-0 text-yellow-500" aria-hidden="true" />
                {h}
              </li>
            ))}
          </ul>
        </div>
      )}
      {edu.coursework && (
        <div className="mt-4">
          <p className="mb-2 font-heading text-[10px] font-black uppercase tracking-wider text-muted-foreground">Coursework</p>
          <div className="flex flex-col gap-2">
            {edu.coursework.map((cw) => (
              <div key={cw.category}>
                <p className="mb-1 font-body text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">{cw.category}</p>
                <div className="flex flex-wrap gap-1">
                  {cw.items.map((item) => (
                    <span key={item} className="rounded border border-border bg-secondary px-2 py-0.5 font-body text-[10px] text-secondary-foreground">
                      {item}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function ExperienceCard() {
  return (
    <div className="rounded-2xl border-2 border-border bg-card p-6" style={{ boxShadow: SHADOW }}>
      <div className="mb-4 flex items-center gap-2">
        <span className="flex h-8 w-8 items-center justify-center rounded-lg border-2 border-border" style={{ background: "#C77DFF" }}>
          <Briefcase className="h-4 w-4 text-black" aria-hidden="true" />
        </span>
        <h3 className="font-heading text-xs font-black uppercase tracking-widest text-card-foreground">Experience</h3>
      </div>
      <div className="flex flex-col gap-5">
        {experience.map((exp, i) => {
          const color = ["#FF6B6B", "#F4A261"][i % 2];
          return (
            <div key={exp.id} className="relative pl-4">
              <div className="absolute left-0 top-1.5 h-full w-0.5 rounded-full" style={{ background: color }} aria-hidden="true" />
              <div className="mb-1 flex flex-wrap items-start justify-between gap-2">
                <div>
                  <p className="font-heading text-sm font-black text-card-foreground">{exp.role}</p>
                  <p className="font-body text-xs font-semibold text-muted-foreground">{exp.company}</p>
                </div>
                <span className="shrink-0 rounded border-2 border-border px-2 py-0.5 font-mono text-[10px] font-bold text-black" style={{ background: color }}>
                  {exp.period}
                </span>
              </div>
              <ul className="mt-2 flex flex-col gap-1">
                {exp.bullets.map((b) => (
                  <li key={b} className="flex items-start gap-2 font-body text-xs leading-relaxed text-muted-foreground">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-foreground" aria-hidden="true" />
                    {b}
                  </li>
                ))}
              </ul>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function ResearchCard() {
  return (
    <div className="rounded-2xl border-2 border-border p-6" style={{ background: "#7DF9A4", boxShadow: SHADOW }}>
      <div className="mb-4 flex items-center gap-2">
        <span className="flex h-8 w-8 items-center justify-center rounded-lg border-2 border-black bg-white">
          <FlaskConical className="h-4 w-4 text-black" aria-hidden="true" />
        </span>
        <h3 className="font-heading text-xs font-black uppercase tracking-widest text-black">Research Interests</h3>
      </div>
      <div className="flex flex-wrap gap-2">
        {["Nanomaterial Synthesis","Quantum Chemistry (DFT)","AI Workflow Automation","AFM / STM Microscopy","Lipid Nanoparticles","STEM Education","Computational Materials"].map((t) => (
          <span key={t} className="rounded border-2 border-black bg-white px-2.5 py-1 font-body text-xs font-semibold text-black" style={{ boxShadow: "2px 2px 0 0 #000" }}>
            {t}
          </span>
        ))}
      </div>
    </div>
  );
}

function AcademicCard() {
  return (
    <div className="rounded-2xl border-2 border-border bg-card p-6" style={{ boxShadow: SHADOW }}>
      <div className="mb-3 flex items-center gap-2">
        <span className="flex h-8 w-8 items-center justify-center rounded-lg border-2 border-border" style={{ background: "#FFD166" }}>
          <BookOpen className="h-4 w-4 text-black" aria-hidden="true" />
        </span>
        <h3 className="font-heading text-xs font-black uppercase tracking-widest text-card-foreground">Academic Status</h3>
      </div>
      <p className="font-body text-sm leading-relaxed text-muted-foreground">
        Junior student at Zewail City · GPA 3.825/4.00 · Expected graduation July 2026.
        Currently advancing toward a career at the intersection of nanoscience, AI automation,
        and high-energy STEM outreach.
      </p>
    </div>
  );
}

const BLOCK_COMPONENTS: Record<string, () => JSX.Element | null> = {
  identity: IdentityCard,
  contact: ContactCard,
  "skills-panel": SkillsPanelCard,
  "education-card": EducationCard,
  "experience-card": ExperienceCard,
  research: ResearchCard,
  academic: AcademicCard,
};

// ── Main section ──────────────────────────────────────────────────────────────

export function BiosSection() {
  const { getBlockOrder } = useAdmin();
  const orderedIds = getBlockOrder("bios", DEFAULT_BLOCK_ORDER);

  return (
    <section aria-labelledby="bios-heading" className="mx-auto max-w-7xl px-6 py-16">
      <div className="mx-auto grid max-w-xl gap-6 lg:mx-0 lg:max-w-none lg:grid-cols-2">
        {orderedIds.map((id) => {
          const Card = BLOCK_COMPONENTS[id];
          if (!Card) return null;
          return <Card key={id} />;
        })}
      </div>
    </section>
  );
}
