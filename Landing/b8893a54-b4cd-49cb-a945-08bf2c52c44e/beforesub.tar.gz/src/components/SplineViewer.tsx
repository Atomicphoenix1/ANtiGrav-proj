import { lazy, Suspense } from "react";
import { Loader2 } from "lucide-react";

// bundle-dynamic-imports: heavy 3D viewer loaded only when hero mounts
const Spline = lazy(() => import("@splinetool/react-spline"));

const SPLINE_URL =
  "https://prod.spline.design/eH5nyuI8badcW29P/scene.splinecode";

// ─── Fixed dark environment color for the Spline scene ───────────────────────
// This value is hardcoded and intentionally NOT a CSS custom property.
// It must NEVER inherit from the page's randomized theme palette, because
// the 3D scene is modelled against a specific dark environment (#121212).
// Using a direct style object (bypasses CSS inheritance entirely).
const SPLINE_BG = "#121212" as const;

export function SplineViewer() {
  return (
    // Isolation shell: all styles applied via `style` (not className)
    // so no Tailwind utility can accidentally be overridden by :root vars.
    <div
      style={{
        position: "relative",
        width: "100%",
        height: "100%",
        overflow: "hidden",
        borderRadius: "1rem",
        background: SPLINE_BG,   // ← fixed, never theme-driven
        isolation: "isolate",    // creates a new stacking context
      }}
      aria-label="Interactive 3D scene"
    >
      <Suspense fallback={<SplineSkeleton />}>
        <Spline
          scene={SPLINE_URL}
          style={{
            width: "100%",
            height: "100%",
            // Keep the canvas background pinned — prevents any semi-transparent
            // canvas from bleeding the parent page background through.
            background: SPLINE_BG,
          }}
        />
      </Suspense>
    </div>
  );
}

function SplineSkeleton() {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        width: "100%",
        height: "100%",
        background: SPLINE_BG,
        borderRadius: "1rem",
      }}
    >
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "0.75rem", color: "#94a3b8" }}>
        <Loader2
          style={{ width: "2rem", height: "2rem", color: "#6366f1" }}
          className="animate-spin"
          aria-hidden="true"
        />
        <span style={{ fontSize: "0.75rem", fontWeight: 500, letterSpacing: "0.05em" }}>
          Loading 3D scene…
        </span>
      </div>
    </div>
  );
}
