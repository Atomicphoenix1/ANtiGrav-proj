import { useState } from "react";
import { Play, Loader2, Terminal, X, Circle } from "lucide-react";
import { simulateExecution, type ExecutionResult } from "@/lib/codeRunner";
import type { CodePreviewConfig } from "@/data/portfolioData";

interface CodePreviewWindowProps {
  projectId: string;
  config: CodePreviewConfig;
  onClose: () => void;
}

type RunState = "idle" | "running" | "done" | "error";

// Attach line numbers to display code
function withLineNumbers(code: string): { num: number; text: string }[] {
  return code.split("\n").map((text, i) => ({ num: i + 1, text }));
}

export function CodePreviewWindow({ projectId, config, onClose }: CodePreviewWindowProps) {
  const [runState, setRunState] = useState<RunState>("idle");
  const [result, setResult] = useState<ExecutionResult | null>(null);
  const lines = withLineNumbers(config.displayCode);

  async function handleRun() {
    if (runState === "running") return;
    setRunState("running");
    setResult(null);
    try {
      const res = await simulateExecution(projectId);
      setResult(res);
      setRunState(res.success ? "done" : "error");
    } catch {
      setRunState("error");
    }
  }

  // Close on Escape
  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === "Escape") onClose();
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={`Code preview: ${projectId}`}
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      onKeyDown={handleKeyDown}
    >
      {/* Scrim */}
      <button
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={onClose}
        aria-label="Close code preview"
        tabIndex={-1}
      />

      {/* ── IDE Window ─────────────────────────────────────────────────── */}
      <div
        className="relative z-10 flex w-full max-w-2xl flex-col overflow-hidden rounded-xl shadow-2xl"
        style={{ background: "#0d1117", border: "1px solid #30363d" }}
      >
        {/* ── Title bar ── */}
        <div
          className="flex items-center justify-between px-4 py-2.5"
          style={{ background: "#161b22", borderBottom: "1px solid #30363d" }}
        >
          {/* Traffic lights */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={onClose}
              aria-label="Close"
              className="group relative flex h-3 w-3 cursor-pointer items-center justify-center rounded-full"
              style={{ background: "#ff5f57" }}
            >
              <X
                className="h-2 w-2 opacity-0 transition-opacity group-hover:opacity-100"
                style={{ color: "#9a0000" }}
                aria-hidden="true"
              />
            </button>
            <span
              className="flex h-3 w-3 items-center justify-center rounded-full"
              style={{ background: "#febc2e" }}
              aria-hidden="true"
            >
              <Circle className="h-1.5 w-1.5 opacity-0" aria-hidden="true" />
            </span>
            <span
              className="flex h-3 w-3 items-center justify-center rounded-full"
              style={{ background: "#28c840" }}
              aria-hidden="true"
            />
          </div>

          {/* File name */}
          <span className="font-mono text-xs" style={{ color: "#8b949e" }}>
            {projectId}.{config.language === "python" ? "py" : config.language === "javascript" ? "js" : config.language}
          </span>

          {/* Language badge */}
          <span
            className="rounded px-2 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-wide"
            style={{ background: "#21262d", color: "#8b949e" }}
          >
            {config.language}
          </span>
        </div>

        {/* ── Code pane ── */}
        <div className="overflow-x-auto" style={{ background: "#0d1117" }}>
          <table className="w-full border-collapse">
            <tbody>
              {lines.map(({ num, text }) => (
                <tr key={num} className="group">
                  {/* Gutter */}
                  <td
                    className="select-none pr-4 pl-5 pt-0 pb-0 text-right font-mono text-xs leading-6"
                    style={{ color: "#3d444d", minWidth: "2.5rem", userSelect: "none" }}
                    aria-hidden="true"
                  >
                    {num}
                  </td>
                  {/* Code */}
                  <td
                    className="pr-6 font-mono text-xs leading-6"
                    style={{ color: "#e6edf3", whiteSpace: "pre" }}
                  >
                    {text || " "}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {/* Breathing room at the bottom of code */}
          <div className="h-3" />
        </div>

        {/* ── Output / terminal pane ── */}
        <div style={{ borderTop: "1px solid #30363d", background: "#010409" }}>
          {/* Terminal header */}
          <div
            className="flex items-center gap-2 px-4 py-2"
            style={{ borderBottom: "1px solid #21262d" }}
          >
            <Terminal className="h-3.5 w-3.5" style={{ color: "#3fb950" }} aria-hidden="true" />
            <span className="font-mono text-xs font-semibold" style={{ color: "#8b949e" }}>
              Terminal — Output
            </span>
            {runState === "done" && (
              <span
                className="ms-auto rounded-full px-2 py-0.5 font-mono text-[10px] font-semibold"
                style={{ background: "#1a3a28", color: "#3fb950" }}
              >
                ✓ EXIT 0
              </span>
            )}
            {runState === "error" && (
              <span
                className="ms-auto rounded-full px-2 py-0.5 font-mono text-[10px] font-semibold"
                style={{ background: "#3a1a1a", color: "#f85149" }}
              >
                ✗ EXIT 1
              </span>
            )}
          </div>

          {/* Output content */}
          <div className="min-h-[110px] p-4">
            {runState === "idle" && (
              <p className="font-mono text-xs" style={{ color: "#3d444d" }}>
                <span style={{ color: "#8b949e" }}>$</span>{" "}
                <span className="terminal-cursor" aria-hidden="true" />
                <span className="sr-only">Ready — press Run to execute</span>
              </p>
            )}

            {runState === "running" && (
              <div className="flex items-center gap-2" style={{ color: "#e3b341" }}>
                <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
                <span className="font-mono text-xs">Executing on secure server…</span>
              </div>
            )}

            {(runState === "done" || runState === "error") && result && (
              <pre
                className="font-mono text-xs leading-relaxed whitespace-pre-wrap"
                style={{ color: result.success ? "#3fb950" : "#f85149" }}
              >
                {result.output}
                {"\n\n"}
                <span style={{ color: "#484f58" }}>
                  — completed in {(result.durationMs / 1000).toFixed(1)}s
                </span>
              </pre>
            )}
          </div>
        </div>

        {/* ── Status bar ── */}
        <div
          className="flex items-center justify-between px-4 py-1.5"
          style={{ background: "#161b22", borderTop: "1px solid #30363d" }}
        >
          <span className="font-mono text-[10px]" style={{ color: "#8b949e" }}>
            display-only · logic runs server-side
          </span>
          <div className="flex gap-3">
            <button
              onClick={onClose}
              className="cursor-pointer font-mono text-[10px] transition-colors"
              style={{ color: "#8b949e" }}
              onMouseEnter={(e) => (e.currentTarget.style.color = "#e6edf3")}
              onMouseLeave={(e) => (e.currentTarget.style.color = "#8b949e")}
            >
              Close
            </button>
            <button
              onClick={handleRun}
              disabled={runState === "running"}
              className="flex cursor-pointer items-center gap-1.5 rounded px-3 py-1 font-mono text-[10px] font-semibold transition-opacity disabled:cursor-not-allowed disabled:opacity-50"
              style={{ background: "#238636", color: "#ffffff" }}
              onMouseEnter={(e) => runState !== "running" && (e.currentTarget.style.opacity = "0.85")}
              onMouseLeave={(e) => (e.currentTarget.style.opacity = "1")}
            >
              {runState === "running" ? (
                <>
                  <Loader2 className="h-3 w-3 animate-spin" aria-hidden="true" />
                  Running…
                </>
              ) : (
                <>
                  <Play className="h-3 w-3" aria-hidden="true" />
                  ▶ Run
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
