import { Play, Pause, X, ExternalLink } from "lucide-react";
import { audioManager, useAudioManager } from "@/lib/audioManager";
import type { Project } from "@/data/portfolioData";

const ACCENT_COLORS = ["#7DF9A4", "#FFD166", "#C77DFF", "#4CC9F0", "#FF6B6B", "#F4A261"];
const SHADOW = "6px 6px 0 0 hsl(var(--border) / 1)";

interface Props {
  project: Project;
  onClose: () => void;
}

export function ProjectDetailModal({ project, onClose }: Props) {
  const { playingId } = useAudioManager();
  const isPlaying = playingId === project.id;

  function handleAudioToggle() {
    if (!project.audioSrc) return;
    audioManager.toggle(project.id, project.audioSrc);
  }

  function handleBackdropClick(e: React.MouseEvent) {
    if (e.target === e.currentTarget) onClose();
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-8"
      style={{ background: "rgba(0,0,0,0.65)" }}
      onClick={handleBackdropClick}
      role="dialog"
      aria-modal="true"
      aria-label={project.title}
    >
      <div
        className="relative flex max-h-[90dvh] w-full max-w-2xl flex-col overflow-hidden rounded-2xl border-2 border-border bg-background"
        style={{ boxShadow: SHADOW }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header bar */}
        <div
          className="flex shrink-0 items-center justify-between border-b-2 border-border px-6 py-4"
          style={{ background: "#FFD166" }}
        >
          <span className="font-mono text-xs font-black uppercase tracking-widest text-black">
            Project Detail
          </span>
          <button
            onClick={onClose}
            aria-label="Close project detail"
            className="flex h-8 w-8 items-center justify-center rounded-lg border-2 border-black bg-black text-white transition-opacity hover:opacity-75"
          >
            <X className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>

        {/* Scrollable body */}
        <div className="flex-1 overflow-y-auto px-6 py-6">
          {/* Title + audio */}
          <div className="mb-5 flex flex-wrap items-start justify-between gap-3">
            <h2 className="font-heading text-2xl font-black uppercase leading-tight tracking-tight text-foreground">
              {project.title}
            </h2>

            {project.audioSrc && (
              <button
                onClick={handleAudioToggle}
                aria-label={isPlaying ? `Pause "${project.title}"` : `Play "${project.title}" story`}
                className={[
                  "flex shrink-0 items-center gap-2 rounded-full border-2 border-border px-4 py-2 font-mono text-xs font-bold transition-all",
                  isPlaying
                    ? "border-green-500 bg-green-500/10 text-green-600"
                    : "bg-card text-card-foreground hover:-translate-y-px",
                ].join(" ")}
                style={isPlaying ? {} : { boxShadow: "2px 2px 0 0 hsl(var(--border) / 1)" }}
              >
                {isPlaying ? (
                  <>
                    <span className="flex h-3.5 items-end gap-[2px]" aria-hidden="true">
                      <span className="waveform-bar" style={{ animationDelay: "0ms" }} />
                      <span className="waveform-bar" style={{ animationDelay: "150ms" }} />
                      <span className="waveform-bar" style={{ animationDelay: "75ms" }} />
                    </span>
                    Playing
                  </>
                ) : (
                  <>
                    <Play className="h-3 w-3" aria-hidden="true" />
                    Play Story
                  </>
                )}
              </button>
            )}
          </div>

          {/* Description */}
          <div
            className="mb-6 rounded-xl border-2 border-border p-4"
            style={{ background: "#4CC9F020" }}
          >
            <p className="font-body text-sm leading-relaxed text-foreground">
              {project.description}
            </p>
          </div>

          {/* Tech stack */}
          <div className="mb-6">
            <p className="mb-3 font-heading text-[10px] font-black uppercase tracking-widest text-muted-foreground">
              Tech Stack
            </p>
            <div className="flex flex-wrap gap-2">
              {project.techStack.map((tech, i) => (
                <span
                  key={tech}
                  className="rounded border-2 border-border px-3 py-1 font-mono text-xs font-semibold text-foreground"
                  style={{ background: ACCENT_COLORS[i % ACCENT_COLORS.length] + "30" }}
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>

          {/* Links */}
          {project.links && project.links.length > 0 && (
            <div>
              <p className="mb-3 font-heading text-[10px] font-black uppercase tracking-widest text-muted-foreground">
                Links
              </p>
              <div className="flex flex-wrap gap-3">
                {project.links.map((link) => (
                  <a
                    key={link.label}
                    href={link.url}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-2 rounded-lg border-2 border-border bg-card px-4 py-2.5 font-mono text-xs font-bold text-card-foreground transition-all hover:-translate-y-px hover:shadow-md"
                    style={{ boxShadow: "3px 3px 0 0 hsl(var(--border) / 1)" }}
                  >
                    <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
                    {link.label}
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
