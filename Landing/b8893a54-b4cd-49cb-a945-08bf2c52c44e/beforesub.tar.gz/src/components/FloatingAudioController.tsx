import { useMemo } from "react";
import { Volume2, VolumeX, StopCircle } from "lucide-react";
import { audioManager, useAudioManager } from "@/lib/audioManager";
import { projects } from "@/data/portfolioData";

// Resolve a track ID to a human-readable label
function resolveTrackName(id: string | null): string {
  if (!id) return "";
  if (id === "welcome") return "Welcome narration";
  return projects.find((p) => p.id === id)?.title ?? id;
}

export function FloatingAudioController() {
  const { playingId, muted } = useAudioManager();
  const trackName = useMemo(() => resolveTrackName(playingId), [playingId]);
  const isPlaying = playingId !== null;
  const showBars = isPlaying && !muted;

  return (
    <div
      role="status"
      aria-live="polite"
      aria-label={isPlaying ? `Now playing: ${trackName}` : "Audio controller"}
      className={[
        "fixed bottom-6 right-6 z-50 flex items-center gap-2.5",
        "rounded-full border border-border bg-card/90 px-3.5 py-2",
        "shadow-xl backdrop-blur-md",
        "transition-all duration-300 ease-out",
        isPlaying ? "opacity-100 scale-100" : "opacity-60 scale-95",
      ].join(" ")}
    >
      {/* Animated waveform — only when audio is audible */}
      {showBars && (
        <span className="flex items-end gap-[3px] h-4 shrink-0" aria-hidden="true">
          <span className="waveform-bar" style={{ animationDelay: "0ms" }} />
          <span className="waveform-bar" style={{ animationDelay: "150ms" }} />
          <span className="waveform-bar" style={{ animationDelay: "75ms" }} />
          <span className="waveform-bar" style={{ animationDelay: "225ms" }} />
        </span>
      )}

      {/* Track label */}
      {isPlaying && (
        <span className="max-w-[150px] truncate font-body text-xs font-medium text-foreground">
          {trackName}
        </span>
      )}

      {/* Stop button — only when a track is active */}
      {isPlaying && (
        <button
          onClick={() => audioManager.pause(playingId!)}
          aria-label={`Stop "${trackName}"`}
          title="Stop"
          className="cursor-pointer rounded-full p-1 text-muted-foreground transition-colors hover:text-foreground"
        >
          <StopCircle className="h-3.5 w-3.5" aria-hidden="true" />
        </button>
      )}

      {/* Mute / unmute toggle — always visible */}
      <button
        onClick={() => audioManager.toggleMute()}
        aria-label={muted ? "Unmute all audio" : "Mute all audio"}
        title={muted ? "Unmute" : "Mute"}
        className={[
          "cursor-pointer rounded-full p-1 transition-colors",
          muted ? "text-destructive hover:text-foreground" : "text-muted-foreground hover:text-accent",
        ].join(" ")}
      >
        {muted ? (
          <VolumeX className="h-4 w-4" aria-hidden="true" />
        ) : (
          <Volume2 className="h-4 w-4" aria-hidden="true" />
        )}
      </button>
    </div>
  );
}
