import { Settings, X } from "lucide-react";
import { useAdmin } from "@/context/AdminContext";

export function AdminBanner() {
  const { isAdmin, toggleAdmin, setPanelOpen } = useAdmin();
  if (!isAdmin) return null;

  return (
    <div
      className="fixed top-0 left-0 right-0 z-[999] flex items-center justify-between px-4 py-2 font-mono text-xs font-bold text-black"
      style={{ background: "#FFD166", borderBottom: "2px solid #000" }}
    >
      <div className="flex items-center gap-2">
        <span className="flex h-5 w-5 items-center justify-center rounded border-2 border-black bg-black">
          <Settings className="h-3 w-3 text-yellow-300" aria-hidden="true" />
        </span>
        ADMIN MODE — repeat combo to exit
      </div>
      <div className="flex items-center gap-2">
        <button
          onClick={() => setPanelOpen(true)}
          className="rounded border-2 border-black bg-black px-3 py-0.5 text-yellow-300 transition-all hover:-translate-y-px hover:shadow-md"
        >
          Open Panel
        </button>
        <button
          onClick={toggleAdmin}
          className="flex h-6 w-6 items-center justify-center rounded border-2 border-black hover:bg-black/10"
          aria-label="Exit admin mode"
        >
          <X className="h-3.5 w-3.5" aria-hidden="true" />
        </button>
      </div>
    </div>
  );
}
