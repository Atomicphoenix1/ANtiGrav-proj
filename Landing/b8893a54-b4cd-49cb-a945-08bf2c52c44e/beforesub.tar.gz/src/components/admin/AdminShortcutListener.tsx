import { useAdminShortcut } from "@/hooks/useAdminShortcut";

export function AdminShortcutListener() {
  useAdminShortcut();
  return null;
}
