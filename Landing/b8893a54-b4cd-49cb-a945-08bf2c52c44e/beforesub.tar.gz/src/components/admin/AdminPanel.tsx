import { useState, useEffect } from "react";
import {
  DndContext,
  closestCenter,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from "@dnd-kit/core";
import {
  SortableContext,
  verticalListSortingStrategy,
  rectSortingStrategy,
  arrayMove,
  useSortable,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { SortableItem } from "./SortableItem";
import { useAdmin } from "@/context/AdminContext";
import {
  tabs as defaultTabs,
  personal,
  projects,
  experience,
  education,
  skills,
} from "@/data/portfolioData";
import { RotateCcw, ChevronDown, ChevronRight } from "lucide-react";

// ── Block definitions per section ─────────────────────────────────────────────

const SECTION_BLOCKS: Record<string, { id: string; label: string }[]> = {
  projects: projects.map((p) => ({ id: p.id, label: p.title })),
  experience: experience.map((e) => ({ id: e.id, label: `${e.role} @ ${e.company}` })),
  skills: skills.map((g) => ({ id: g.category, label: g.category })),
  bios: [
    { id: "identity", label: "Identity Card" },
    { id: "contact", label: "Contact & Links" },
    { id: "skills-panel", label: "Core Skills" },
    { id: "education-card", label: "Education" },
    { id: "experience-card", label: "Experience" },
    { id: "research", label: "Research Interests" },
    { id: "academic", label: "Academic Status" },
  ],
};

// ── Grid tile for block reorder ───────────────────────────────────────────────

function GridTile({ id, label, index }: { id: string; label: string; index: number }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id });
  return (
    <div
      ref={setNodeRef}
      style={{
        transform: CSS.Transform.toString(transform),
        transition,
        opacity: isDragging ? 0.35 : 1,
        zIndex: isDragging ? 20 : undefined,
      }}
      className="relative flex min-h-[54px] cursor-grab touch-none flex-col items-center justify-center rounded border-2 border-black bg-white p-2 text-center active:cursor-grabbing"
      {...attributes}
      {...listeners}
    >
      <span
        className="absolute left-1.5 top-1 font-mono text-[8px] font-bold"
        style={{ color: "#00000030" }}
      >
        {index + 1}
      </span>
      <span className="font-mono text-[9px] font-semibold leading-tight" style={{ color: "#000" }}>
        {label}
      </span>
    </div>
  );
}

// ── Sortable block grid ───────────────────────────────────────────────────────

function BlockReorder({ sectionId }: { sectionId: string }) {
  const blocks = SECTION_BLOCKS[sectionId];
  if (!blocks || blocks.length < 2) return null;

  const { getBlockOrder, setBlockOrder } = useAdmin();
  const defaultIds = blocks.map((b) => b.id);
  const persisted = getBlockOrder(sectionId, defaultIds);
  const [localOrder, setLocalOrder] = useState<string[]>(persisted);
  const sensors = useSensors(useSensor(PointerSensor));

  useEffect(() => {
    setLocalOrder(getBlockOrder(sectionId, defaultIds));
  }, [persisted.join(",")]);

  const orderedBlocks = localOrder
    .map((id) => blocks.find((b) => b.id === id))
    .filter(Boolean) as { id: string; label: string }[];

  function onDragEnd(e: DragEndEvent) {
    const { active, over } = e;
    if (!over || active.id === over.id) return;
    const newOrder = arrayMove(localOrder, localOrder.indexOf(active.id as string), localOrder.indexOf(over.id as string));
    setLocalOrder(newOrder);
    setBlockOrder(sectionId, newOrder);
  }

  return (
    <div className="ml-6 mt-2 border-l-2 border-black/20 pl-3">
      <p className="mb-1.5 font-mono text-[9px] font-bold uppercase tracking-widest" style={{ color: "#000" }}>
        Blocks — drag to reorder
      </p>
      <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={onDragEnd}>
        <SortableContext items={localOrder} strategy={rectSortingStrategy}>
          <div className="grid grid-cols-2 gap-1.5">
            {orderedBlocks.map((b, i) => (
              <GridTile key={b.id} id={b.id} label={b.label} index={i} />
            ))}
          </div>
        </SortableContext>
      </DndContext>
    </div>
  );
}

// ── Section reorder within a tab ──────────────────────────────────────────────

function SectionReorder({ tabId, defaultIds }: { tabId: string; defaultIds: string[] }) {
  const { getSectionOrder, setSectionOrder } = useAdmin();
  const persisted = getSectionOrder(tabId, defaultIds);
  const [localOrder, setLocalOrder] = useState<string[]>(persisted);
  const sensors = useSensors(useSensor(PointerSensor));

  useEffect(() => {
    setLocalOrder(getSectionOrder(tabId, defaultIds));
  }, [persisted.join(",")]);

  function onDragEnd(e: DragEndEvent) {
    const { active, over } = e;
    if (!over || active.id === over.id) return;
    const newOrder = arrayMove(localOrder, localOrder.indexOf(active.id as string), localOrder.indexOf(over.id as string));
    setLocalOrder(newOrder);
    setSectionOrder(tabId, newOrder);
  }

  return (
    <div className="ml-6 mt-1 flex flex-col gap-1 border-l-2 border-black/20 pl-3">
      <p className="font-mono text-[9px] font-bold uppercase tracking-widest" style={{ color: "#000" }}>
        Sections
      </p>
      <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={onDragEnd}>
        <SortableContext items={localOrder} strategy={verticalListSortingStrategy}>
          {localOrder.map((id) => (
            <div key={id}>
              <SortableItem id={id}>
                <span className="font-mono text-[10px] capitalize" style={{ color: "#000" }}>{id}</span>
              </SortableItem>
              <BlockReorder sectionId={id} />
            </div>
          ))}
        </SortableContext>
      </DndContext>
    </div>
  );
}

// ── Layout tab ────────────────────────────────────────────────────────────────

function LayoutTab() {
  const { orderedTabs, setTabOrder, getTabLabel, setTabLabel } = useAdmin();
  const sensors = useSensors(useSensor(PointerSensor));
  const [expandedTab, setExpandedTab] = useState<string | null>(null);

  function onTabDragEnd(e: DragEndEvent) {
    const { active, over } = e;
    if (!over || active.id === over.id) return;
    const ids = orderedTabs.map((t) => t.id);
    setTabOrder(arrayMove(ids, ids.indexOf(active.id as string), ids.indexOf(over.id as string)));
  }

  return (
    <div className="flex flex-col gap-4">
      <p className="font-mono text-[10px] font-bold uppercase tracking-widest" style={{ color: "#00000080" }}>
        Tab Order — drag to reorder, click ▶ for blocks
      </p>
      <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={onTabDragEnd}>
        <SortableContext items={orderedTabs.map((t) => t.id)} strategy={verticalListSortingStrategy}>
          <div className="flex flex-col gap-2">
            {orderedTabs.map((tab) => {
              const isExpanded = expandedTab === tab.id;
              const hasContent =
                tab.sectionIds.length > 1 ||
                tab.sectionIds.some((s) => SECTION_BLOCKS[s]?.length > 1);
              return (
                <div key={tab.id}>
                  <SortableItem id={tab.id}>
                    <div className="flex items-center gap-2">
                      <Input
                        value={getTabLabel(tab.id)}
                        onChange={(e) => setTabLabel(tab.id, e.target.value)}
                        className="h-7 flex-1 border-2 border-black bg-white font-mono text-xs text-black"
                        style={{ color: "#000", background: "#fff" }}
                        onClick={(e) => e.stopPropagation()}
                      />
                      {hasContent && (
                        <button
                          onClick={() => setExpandedTab(isExpanded ? null : tab.id)}
                          className="flex h-6 w-6 shrink-0 items-center justify-center rounded border-2 border-black bg-black"
                          aria-label="Toggle blocks"
                        >
                          {isExpanded
                            ? <ChevronDown className="h-3.5 w-3.5 text-yellow-300" />
                            : <ChevronRight className="h-3.5 w-3.5 text-yellow-300" />}
                        </button>
                      )}
                    </div>
                  </SortableItem>

                  {isExpanded && (
                    tab.sectionIds.length > 1
                      ? <SectionReorder tabId={tab.id} defaultIds={tab.sectionIds as string[]} />
                      : <BlockReorder sectionId={tab.sectionIds[0]} />
                  )}
                </div>
              );
            })}
          </div>
        </SortableContext>
      </DndContext>
    </div>
  );
}

// ── Content helpers ───────────────────────────────────────────────────────────

function TextField({
  label,
  textKey,
  fallback,
  multiline,
}: {
  label: string;
  textKey: string;
  fallback: string;
  multiline?: boolean;
}) {
  const { getText, setText } = useAdmin();
  const value = getText(textKey, fallback);

  return (
    <div className="flex flex-col gap-1">
      <label className="font-mono text-[9px] font-bold uppercase tracking-widest" style={{ color: "#00000080" }}>
        {label}
      </label>
      {multiline ? (
        <Textarea
          value={value}
          onChange={(e) => setText(textKey, e.target.value)}
          className="min-h-[60px] border-2 border-black font-body text-xs text-black"
          style={{ color: "#000", background: "#fff" }}
          rows={3}
        />
      ) : (
        <Input
          value={value}
          onChange={(e) => setText(textKey, e.target.value)}
          className="h-8 border-2 border-black font-body text-xs text-black"
          style={{ color: "#000", background: "#fff" }}
        />
      )}
    </div>
  );
}

function ContentSection({ title, children }: { title: string; children: React.ReactNode }) {
  const [open, setOpen] = useState(true);
  return (
    <div className="rounded border-2 border-black overflow-hidden">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center justify-between px-3 py-2 font-mono text-[10px] font-bold uppercase tracking-widest"
        style={{ background: "#FFD166", color: "#000" }}
      >
        {title}
        {open
          ? <ChevronDown className="h-3.5 w-3.5 text-black" />
          : <ChevronRight className="h-3.5 w-3.5 text-black" />}
      </button>
      {open && (
        <div className="flex flex-col gap-3 p-3" style={{ background: "#fff" }}>
          {children}
        </div>
      )}
    </div>
  );
}

function ContentTab() {
  return (
    <div className="flex flex-col gap-4">
      <ContentSection title="Personal">
        <TextField label="Name" textKey="personal.name" fallback={personal.name} />
        <TextField label="Title" textKey="personal.title" fallback={personal.title} />
        <TextField label="Tagline" textKey="personal.tagline" fallback={personal.tagline} multiline />
      </ContentSection>

      {projects.map((p) => (
        <ContentSection key={p.id} title={`Project: ${p.title}`}>
          <TextField label="Title" textKey={`project.${p.id}.title`} fallback={p.title} />
          <TextField label="Description" textKey={`project.${p.id}.description`} fallback={p.description} multiline />
          <TextField label="Tech Stack (comma-separated)" textKey={`project.${p.id}.techStack`} fallback={p.techStack.join(", ")} />
        </ContentSection>
      ))}

      {experience.map((exp) => (
        <ContentSection key={exp.id} title={`Experience: ${exp.company}`}>
          <TextField label="Role" textKey={`exp.${exp.id}.role`} fallback={exp.role} />
          <TextField label="Company" textKey={`exp.${exp.id}.company`} fallback={exp.company} />
          <TextField label="Period" textKey={`exp.${exp.id}.period`} fallback={exp.period} />
          {exp.bullets.map((b, i) => (
            <TextField key={i} label={`Bullet ${i + 1}`} textKey={`exp.${exp.id}.bullet.${i}`} fallback={b} multiline />
          ))}
        </ContentSection>
      ))}

      {education.map((edu) => (
        <ContentSection key={edu.id} title="Education">
          <TextField label="Degree" textKey={`edu.${edu.id}.degree`} fallback={edu.degree} />
          <TextField label="Institution" textKey={`edu.${edu.id}.institution`} fallback={edu.institution} />
          <TextField label="Period" textKey={`edu.${edu.id}.period`} fallback={edu.period} />
          <TextField label="Status" textKey={`edu.${edu.id}.status`} fallback={edu.status} />
          {edu.gpa && <TextField label="GPA" textKey={`edu.${edu.id}.gpa`} fallback={edu.gpa} />}
        </ContentSection>
      ))}

      <ContentSection title="Skills">
        {skills.map((group) => (
          <div key={group.category}>
            <p className="mb-1 font-mono text-[9px] font-bold uppercase tracking-widest" style={{ color: "#00000080" }}>
              {group.category}
            </p>
            <TextField label="Items (comma-separated)" textKey={`skills.${group.category}`} fallback={group.items.join(", ")} />
          </div>
        ))}
      </ContentSection>
    </div>
  );
}

// ── Styles tab ────────────────────────────────────────────────────────────────

const STYLE_TARGETS = [
  { key: "hero.name", label: "Hero Name" },
  { key: "hero.title", label: "Hero Title / Tagline" },
  { key: "section.heading", label: "Section Headings" },
  { key: "card.title", label: "Card Titles" },
  { key: "card.body", label: "Card Body Text" },
  { key: "tag", label: "Tags / Badges" },
  { key: "nav.tab", label: "Nav Tabs" },
  { key: "footer", label: "Footer Text" },
];

const FONT_SIZES = ["10px","12px","14px","16px","18px","20px","24px","28px","32px","40px","48px","64px"];
const FONT_WEIGHTS = ["300","400","500","600","700","800","900"];

function StyleRow({ target }: { target: { key: string; label: string } }) {
  const { getStyle, setStyle } = useAdmin();
  const style = getStyle(target.key);

  return (
    <div className="flex flex-col gap-2 rounded border-2 border-black p-3" style={{ background: "#fff" }}>
      <p className="font-mono text-[10px] font-bold uppercase tracking-widest" style={{ color: "#000" }}>
        {target.label}
      </p>
      <div className="grid grid-cols-3 gap-2">
        <div>
          <label className="font-mono text-[9px]" style={{ color: "#00000080" }}>Size</label>
          <select
            value={style.fontSize ?? ""}
            onChange={(e) => setStyle(target.key, { ...style, fontSize: e.target.value || undefined })}
            className="mt-0.5 w-full rounded border-2 border-black px-1.5 py-1 font-mono text-xs"
            style={{ color: "#000", background: "#fff" }}
          >
            <option value="">—</option>
            {FONT_SIZES.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
        <div>
          <label className="font-mono text-[9px]" style={{ color: "#00000080" }}>Weight</label>
          <select
            value={style.fontWeight ?? ""}
            onChange={(e) => setStyle(target.key, { ...style, fontWeight: e.target.value || undefined })}
            className="mt-0.5 w-full rounded border-2 border-black px-1.5 py-1 font-mono text-xs"
            style={{ color: "#000", background: "#fff" }}
          >
            <option value="">—</option>
            {FONT_WEIGHTS.map((w) => <option key={w} value={w}>{w}</option>)}
          </select>
        </div>
        <div>
          <label className="font-mono text-[9px]" style={{ color: "#00000080" }}>Color</label>
          <input
            type="color"
            value={style.color ?? "#000000"}
            onChange={(e) => setStyle(target.key, { ...style, color: e.target.value })}
            className="mt-0.5 h-8 w-full cursor-pointer rounded border-2 border-black p-0.5"
            style={{ background: "#fff" }}
          />
        </div>
      </div>
    </div>
  );
}

function StylesTab() {
  return (
    <div className="flex flex-col gap-3">
      <p className="font-mono text-[10px]" style={{ color: "#00000080" }}>
        Style overrides apply as inline CSS on matching elements.
      </p>
      {STYLE_TARGETS.map((t) => <StyleRow key={t.key} target={t} />)}
    </div>
  );
}

// ── Main panel ────────────────────────────────────────────────────────────────

export function AdminPanel() {
  const { panelOpen, setPanelOpen, resetAll } = useAdmin();

  return (
    <Sheet open={panelOpen} onOpenChange={setPanelOpen}>
      <SheetContent
        side="right"
        className="flex w-full max-w-md flex-col border-l-4 border-black p-0 overflow-hidden"
        style={{ background: "#FFFDF5" }}
      >
        {/* Header */}
        <SheetHeader
          className="shrink-0 border-b-2 border-black px-4 py-3"
          style={{ background: "#FFD166" }}
        >
          <SheetTitle className="font-mono text-sm font-black uppercase tracking-widest text-black">
            Admin Panel
          </SheetTitle>
        </SheetHeader>

        {/* Tabs */}
        <Tabs defaultValue="layout" className="flex min-h-0 flex-1 flex-col">
          <TabsList className="shrink-0 rounded-none border-b-2 border-black bg-white px-2 pt-2">
            {["layout", "content", "styles"].map((v) => (
              <TabsTrigger
                key={v}
                value={v}
                className="rounded border-2 border-transparent font-mono text-[10px] font-bold uppercase tracking-widest data-[state=active]:border-black data-[state=active]:bg-black data-[state=active]:text-yellow-300"
                style={{ color: "#000" }}
              >
                {v}
              </TabsTrigger>
            ))}
          </TabsList>

          {/* Scrollable content area */}
          <div className="min-h-0 flex-1 overflow-y-auto">
            <TabsContent value="layout" className="mt-0 p-4">
              <LayoutTab />
            </TabsContent>
            <TabsContent value="content" className="mt-0 p-4">
              <ContentTab />
            </TabsContent>
            <TabsContent value="styles" className="mt-0 p-4">
              <StylesTab />
            </TabsContent>
          </div>

          {/* Footer */}
          <div className="shrink-0 border-t-2 border-black p-4" style={{ background: "#FFFDF5" }}>
            <Button
              variant="outline"
              size="sm"
              className="w-full border-2 border-black font-mono text-xs font-bold uppercase hover:bg-red-100"
              style={{ color: "#000", background: "#fff" }}
              onClick={() => {
                if (confirm("Reset all admin overrides? This cannot be undone.")) {
                  resetAll();
                }
              }}
            >
              <RotateCcw className="mr-2 h-3.5 w-3.5" />
              Reset All Overrides
            </Button>
          </div>
        </Tabs>
      </SheetContent>
    </Sheet>
  );
}
