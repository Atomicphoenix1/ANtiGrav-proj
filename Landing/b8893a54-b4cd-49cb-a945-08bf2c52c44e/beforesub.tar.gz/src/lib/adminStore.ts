// Admin override persistence — stored in localStorage, never sent anywhere.
export interface TextStyle {
  fontSize?: string;
  fontWeight?: string;
  color?: string;
}

export interface AdminOverrides {
  v: 1;
  tabOrder: string[];
  tabLabels: Record<string, string>;
  sectionOrders: Record<string, string[]>; // tabId → ordered sectionIds
  blockOrders: Record<string, string[]>;   // sectionId → ordered block IDs
  text: Record<string, string>;
  styles: Record<string, TextStyle>;
}

const STORE_KEY = "portfolio-admin-v1";

export function loadOverrides(): AdminOverrides | null {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (parsed?.v !== 1) return null;
    return parsed as AdminOverrides;
  } catch {
    return null;
  }
}

export function saveOverrides(overrides: AdminOverrides): void {
  localStorage.setItem(STORE_KEY, JSON.stringify(overrides));
}

export function clearOverrides(): void {
  localStorage.removeItem(STORE_KEY);
}

export function defaultOverrides(): AdminOverrides {
  return {
    v: 1,
    tabOrder: [],
    tabLabels: {},
    sectionOrders: {},
    blockOrders: {},
    text: {},
    styles: {},
  };
}
