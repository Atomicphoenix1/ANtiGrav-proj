import { useEffect, useRef } from "react";
import { useAdmin } from "@/context/AdminContext";

// Phase 1: hold ArrowLeft + ArrowRight + ArrowUp simultaneously
// Phase 2: type the sequence ↑ ↑ ↓ ← → ↓
const COMBO_KEYS = new Set(["ArrowLeft", "ArrowRight", "ArrowUp"]);
const SEQUENCE = ["ArrowUp", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "ArrowDown"];

export function useAdminShortcut() {
  const { toggleAdmin } = useAdmin();
  const held = useRef<Set<string>>(new Set());
  const phase = useRef<1 | 2>(1);
  const seqIndex = useRef(0);
  const seqTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    function resetSequence() {
      phase.current = 1;
      seqIndex.current = 0;
      if (seqTimer.current) clearTimeout(seqTimer.current);
    }

    function onKeyDown(e: KeyboardEvent) {
      held.current.add(e.key);

      if (phase.current === 1) {
        // Check if all three combo keys are held simultaneously
        if (COMBO_KEYS.size === [...COMBO_KEYS].filter((k) => held.current.has(k)).length) {
          phase.current = 2;
          seqIndex.current = 0;
          // Give 5 seconds to complete the sequence
          if (seqTimer.current) clearTimeout(seqTimer.current);
          seqTimer.current = setTimeout(resetSequence, 5000);
        }
      } else {
        // Phase 2: track the sequence
        const expected = SEQUENCE[seqIndex.current];
        if (e.key === expected) {
          seqIndex.current += 1;
          // Reset the 5s timer on each correct key
          if (seqTimer.current) clearTimeout(seqTimer.current);
          if (seqIndex.current === SEQUENCE.length) {
            // Sequence complete!
            resetSequence();
            toggleAdmin();
          } else {
            seqTimer.current = setTimeout(resetSequence, 5000);
          }
        } else if (COMBO_KEYS.has(e.key)) {
          // Ignore combo keys during sequence
        } else {
          // Wrong key — reset
          resetSequence();
        }
      }
    }

    function onKeyUp(e: KeyboardEvent) {
      held.current.delete(e.key);
    }

    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      if (seqTimer.current) clearTimeout(seqTimer.current);
    };
  }, [toggleAdmin]);
}
