// ─── Career Archive Data ─────────────────────────────────────────────────────
// Folders displayed in the Tab Four "Career Archive" section.

export type FileType = "report" | "code" | "research" | "teaching" | "certificate" | "publication" | "notebook" | "presentation";

export interface ArchiveFile {
  id: string;
  name: string;
  type: FileType;
  year: string;
  description?: string;
}

export interface ArchiveFolder {
  id: string;
  label: string;
  /** Tailwind bg color class — vibrant brutalist palette */
  bgColor: string;
  /** Tailwind text color on the folder header */
  textColor: string;
  emoji: string;
  files: ArchiveFile[];
}

export const archiveFolders: ArchiveFolder[] = [
  {
    id: "projects",
    label: "Projects",
    bgColor: "#7DF9A4",
    textColor: "#000",
    emoji: "⚡",
    files: [
      { id: "proj-1", name: "AI Transcription Pipeline", type: "code", year: "2025", description: "Audio → DOCX/PDF → Telegram automation" },
      { id: "proj-2", name: "Scheduling Automation", type: "code", year: "2025", description: "Google Forms → n8n → HTML visual scheduler" },
      { id: "proj-3", name: "Nanomaterial Characterization", type: "research", year: "2024", description: "AFM/STM analysis of AgNPs, AuNPs, SPIONs" },
      { id: "proj-4", name: "Gaussian DFT Calculations", type: "code", year: "2024", description: "B3LYP/LANL2DZ quantum chemistry jobs" },
    ],
  },
  {
    id: "lab-reports",
    label: "Lab Reports",
    bgColor: "#FFD166",
    textColor: "#000",
    emoji: "🔬",
    files: [
      { id: "lab-1", name: "AgNP Synthesis Report", type: "report", year: "2024" },
      { id: "lab-2", name: "Lipid Nanoparticle Formulation", type: "report", year: "2024" },
      { id: "lab-3", name: "SPION Characterization", type: "report", year: "2024" },
      { id: "lab-4", name: "Micelle Self-Assembly", type: "report", year: "2023" },
      { id: "lab-5", name: "AFM Surface Mapping", type: "report", year: "2024" },
      { id: "lab-6", name: "Gold Nanoparticle (AuNP) Lab", type: "report", year: "2023" },
    ],
  },
  {
    id: "research",
    label: "Research",
    bgColor: "#C77DFF",
    textColor: "#000",
    emoji: "🧪",
    files: [
      { id: "res-1", name: "Nanophysics Concentration Study", type: "research", year: "2025" },
      { id: "res-2", name: "Quantum Mechanics — Wave Functions", type: "notebook", year: "2024" },
      { id: "res-3", name: "Electrodynamics Notes", type: "notebook", year: "2024" },
      { id: "res-4", name: "DFT Literature Review", type: "research", year: "2024" },
    ],
  },
  {
    id: "teaching",
    label: "Teaching",
    bgColor: "#FF6B6B",
    textColor: "#fff",
    emoji: "🎓",
    files: [
      { id: "teach-1", name: "Scratch Curriculum — Level 1", type: "teaching", year: "2025" },
      { id: "teach-2", name: "PictoBlox / AI Level 1 Plan", type: "teaching", year: "2025" },
      { id: "teach-3", name: "Python AI Level 2 Slides", type: "presentation", year: "2025" },
      { id: "teach-4", name: "MIT App Inventor Workshop", type: "teaching", year: "2026" },
      { id: "teach-5", name: "EM2 Physics Tutoring Notes", type: "teaching", year: "2026" },
      { id: "teach-6", name: "Engineering Chemistry Review", type: "teaching", year: "2026" },
    ],
  },
  {
    id: "coursework",
    label: "Coursework",
    bgColor: "#4CC9F0",
    textColor: "#000",
    emoji: "📐",
    files: [
      { id: "cw-1", name: "Linear Algebra — Problem Sets", type: "notebook", year: "2023" },
      { id: "cw-2", name: "ODEs — Solutions Manual", type: "notebook", year: "2023" },
      { id: "cw-3", name: "Wave Motion & Optics", type: "notebook", year: "2023" },
      { id: "cw-4", name: "Mathematical Physics I", type: "notebook", year: "2024" },
      { id: "cw-5", name: "Intro to Computer Science", type: "code", year: "2023" },
    ],
  },
  {
    id: "certificates",
    label: "Certificates",
    bgColor: "#F4A261",
    textColor: "#000",
    emoji: "🏆",
    files: [
      { id: "cert-1", name: "Provost's Honors Roll — S1 2023", type: "certificate", year: "2023" },
      { id: "cert-2", name: "Provost's Honors Roll — S2 2023", type: "certificate", year: "2023" },
      { id: "cert-3", name: "Provost's Honors Roll — S1 2024", type: "certificate", year: "2024" },
      { id: "cert-4", name: "Bonyan Instructor Certification", type: "certificate", year: "2025" },
    ],
  },
];
