// ─── CV Data ─────────────────────────────────────────────────────────────────
// Strongly-typed CV data file, separate from portfolioData.ts.
// Update the values here to keep the site content in sync with your actual CV.

// ─── Interfaces ───────────────────────────────────────────────────────────────

export interface PersonalInfo {
  name: string;
  title: string;
  email: string[];
  phone: string;
  location: string;
  github?: string;
  linkedin?: string;
}

export interface AboutMe {
  summary: string;
  highlights: string[];
}

export interface EducationItem {
  id: string;
  degree: string;
  concentration?: string;
  institution: string;
  location: string;
  period: string;
  status: string;
  gpa?: string;
  honors?: string[];
  coursework?: { category: string; items: string[] }[];
}

export interface ExperienceItem {
  id: string;
  role: string;
  company: string;
  period: string;
  type: "full-time" | "part-time" | "freelance" | "internship" | "volunteer";
  bullets: string[];
}

export interface SkillCategory {
  category: string;
  level?: "beginner" | "intermediate" | "advanced" | "expert";
  items: string[];
}

export interface ProjectItem {
  id: string;
  title: string;
  description: string;
  techStack: string[];
  outcomes?: string[];
  links?: { label: string; url: string }[];
}

// ─── Data ─────────────────────────────────────────────────────────────────────

export const personalInfo: PersonalInfo = {
  name: "Seif Rabie Sakr",
  title: "Nano Scientist & AI Educator",
  email: ["s-seif.sakr@zewailcity.edu.eg", "seefraber31@gmail.com"],
  phone: "+20 121 257 8915",
  location: "Alexandria, Egypt",
  github: "https://github.com/",
};

export const aboutMe: AboutMe = {
  summary:
    "Nano Science junior at Zewail City with a strong track record in AI-powered automation, computational chemistry, and high-energy STEM education. I bridge rigorous scientific training with practical AI tools to build systems that save time and scale knowledge.",
  highlights: [
    "3.825 / 4.00 GPA — Provost's Honors Roll multiple semesters",
    "Built automation pipelines that cut 45-minute manual workflows to under 2 minutes",
    "Instructed 29+ students ages 6–17 across four programming curricula",
    "Hands-on nanomaterial synthesis: AgNPs, AuNPs, SPIONs, Lipid NPs",
  ],
};

export const cvEducation: EducationItem[] = [
  {
    id: "zewail-city",
    degree: "Bachelor of Science in Nano Science",
    concentration: "Nanophysics",
    institution: "University of Science and Technology at Zewail City",
    location: "Giza, Egypt",
    period: "Expected July 2026",
    status: "Junior Student",
    gpa: "3.825 / 4.00",
    honors: ["Provost's Honors Roll (Multiple Semesters)"],
    coursework: [
      {
        category: "Nano Science",
        items: ["Synthesis/Fabrication of Nanomaterials", "Modern Characterization Techniques"],
      },
      {
        category: "Physics",
        items: [
          "Quantum Mechanics I",
          "Electrodynamics I",
          "Mathematical Physics I",
          "Wave Motion & Optics",
        ],
      },
      {
        category: "Mathematics & CS",
        items: [
          "Linear Algebra & Vector Geometry",
          "Ordinary Differential Equations",
          "Intro to Computer Science",
        ],
      },
    ],
  },
];

export const cvExperience: ExperienceItem[] = [
  {
    id: "bonyan-instructor",
    role: "Programming & AI Instructor",
    company: "Bonyan",
    period: "August 2025 – April 2026",
    type: "part-time",
    bullets: [
      "Instructed 29+ unique students (ages 6–17) in focused groups of up to 6, fostering high-energy, engagement-first learning.",
      "Delivered multi-level curriculum: Scratch (12 students), AI Level 1 — PictoBlox/Back to Blocks (13 students), AI Level 2 — Python-based (8 students), Mobile App Development — MIT App Inventor (4 students).",
      "Guided students from visual block-based logic (Scratch/PictoBlox) to text-based Python programming.",
      "Led immersive Trial Sessions with a charismatic teaching style, consistently converting newcomers into long-term motivated students.",
    ],
  },
  {
    id: "freelance-tutor",
    role: "University Science & Mathematics Tutor",
    company: "Independent / Freelance",
    period: "March 2026 – Present",
    type: "freelance",
    bullets: [
      "Tutored university engineering students in foundational sciences — Physics (EM2, Vector Mechanics) and Engineering Chemistry.",
    ],
  },
];

export const cvSkills: SkillCategory[] = [
  {
    category: "AI & Automation",
    level: "advanced",
    items: ["Prompt-based Automation", "n8n Workflow Design", "Agentic AI Pipelines"],
  },
  {
    category: "Programming",
    level: "intermediate",
    items: ["Python (Fundamentals, Code Reading, Debugging)"],
  },
  {
    category: "Scientific Tools",
    level: "advanced",
    items: [
      "Computational Chemistry (Gaussian 16)",
      "DFT / B3LYP calculations",
      "Nanomaterial Synthesis (AgNPs, AuNPs, SPIONs, Lipid NPs)",
      "Material Characterization (AFM / STM)",
    ],
  },
  {
    category: "Software & Platforms",
    level: "intermediate",
    items: ["Google Workspace", "n8n", "AI Studio", "MIT App Inventor", "Scratch / PictoBlox"],
  },
  {
    category: "Languages",
    items: ["Arabic (Native)", "English (Professional Working Proficiency)"],
  },
];

export const cvProjects: ProjectItem[] = [
  {
    id: "transcription-pipeline",
    title: "AI Transcription Pipeline",
    description:
      "End-to-end automated transcription pipeline that processes audio records into formatted Word Docs/PDFs and distributes them hands-free to Telegram channels.",
    techStack: ["AI Studio", "n8n", "Telegram API"],
    outcomes: [
      "Eliminated manual transcription work for weekly audio records",
      "Output delivered automatically within minutes of recording completion",
    ],
  },
  {
    id: "scheduling-automation",
    title: "Scheduling & Personnel Automation",
    description:
      "Visual scheduling application connecting Google Forms to an HTML UI via n8n. Reduced slot coordination from a 45-minute manual process to under 2 minutes — a 95%+ efficiency gain.",
    techStack: ["n8n", "Google Forms", "HTML/CSS", "JavaScript"],
    outcomes: [
      "95%+ reduction in coordination time (45 min → <2 min)",
      "Adopted by the operations team for recurring scheduling workflows",
    ],
  },
  {
    id: "computational-chemistry",
    title: "Computational Chemistry & Nanomaterial Characterization",
    description:
      "Quantum chemistry calculations using Gaussian software, plus lab synthesis and characterization of AgNPs, AuNPs, Lipid NPs, SPIONs, and Micelles using AFM/STM microscopy.",
    techStack: ["Gaussian 16", "DFT/B3LYP", "AFM", "STM", "Python"],
    outcomes: [
      "Converged SCF calculations for multi-hundred-atom nanoparticle clusters",
      "Characterized surface morphology via AFM/STM imaging",
    ],
  },
];
