import { createContext, useContext, useState, useCallback, useEffect, type ReactNode } from "react";
import {
  loadOverrides,
  saveOverrides,
  clearOverrides,
  defaultOverrides,
  type AdminOverrides,
  type TextStyle,
} from "@/lib/adminStore";
import { tabs as defaultTabs, type Tab } from "@/data/portfolioData";

interface AdminContextValue {
  isAdmin: boolean;
  toggleAdmin: () => void;
  panelOpen: boolean;
  setPanelOpen: (open: boolean) => void;

  // Tabs
  orderedTabs: Tab[];
  setTabOrder: (ids: string[]) => void;
  getTabLabel: (id: string) => string;
  setTabLabel: (id: string, label: string) => void;

  // Section order within a tab
  getSectionOrder: (tabId: string, defaultIds: string[]) => string[];
  setSectionOrder: (tabId: string, ids: string[]) => void;

  // Block order within a section
  getBlockOrder: (sectionId: string, defaultIds: string[]) => string[];
  setBlockOrder: (sectionId: string, ids: string[]) => void;

  // Text overrides
  getText: (key: string, fallback: string) => string;
  setText: (key: string, value: string) => void;

  // Style overrides
  getStyle: (key: string) => TextStyle;
  setStyle: (key: string, style: TextStyle) => void;

  resetAll: () => void;
  overrides: AdminOverrides;
}

const AdminContext = createContext<AdminContextValue | null>(null);

export function AdminProvider({ children }: { children: ReactNode }) {
  const [isAdmin, setIsAdmin] = useState(false);
  const [panelOpen, setPanelOpen] = useState(false);
  const [overrides, setOverrides] = useState<AdminOverrides>(() => loadOverrides() ?? defaultOverrides());

  const persist = useCallback((next: AdminOverrides) => {
    setOverrides(next);
    saveOverrides(next);
  }, []);

  const toggleAdmin = useCallback(() => {
    setIsAdmin((v) => {
      const next = !v;
      if (!next) setPanelOpen(false);
      return next;
    });
  }, []);

  const orderedTabs = (() => {
    const order = overrides.tabOrder;
    if (!order.length) return defaultTabs;
    const map = Object.fromEntries(defaultTabs.map((t) => [t.id, t]));
    return order.map((id) => map[id]).filter(Boolean) as Tab[];
  })();

  const setTabOrder = useCallback((ids: string[]) => {
    persist({ ...overrides, tabOrder: ids });
  }, [overrides, persist]);

  const getTabLabel = useCallback((id: string) => {
    if (overrides.tabLabels[id]) return overrides.tabLabels[id];
    return defaultTabs.find((t) => t.id === id)?.label ?? id;
  }, [overrides.tabLabels]);

  const setTabLabel = useCallback((id: string, label: string) => {
    persist({ ...overrides, tabLabels: { ...overrides.tabLabels, [id]: label } });
  }, [overrides, persist]);

  const getSectionOrder = useCallback((tabId: string, defaultIds: string[]) => {
    return overrides.sectionOrders[tabId] ?? defaultIds;
  }, [overrides.sectionOrders]);

  const setSectionOrder = useCallback((tabId: string, ids: string[]) => {
    persist({ ...overrides, sectionOrders: { ...overrides.sectionOrders, [tabId]: ids } });
  }, [overrides, persist]);

  const getBlockOrder = useCallback((sectionId: string, defaultIds: string[]) => {
    return overrides.blockOrders[sectionId] ?? defaultIds;
  }, [overrides.blockOrders]);

  const setBlockOrder = useCallback((sectionId: string, ids: string[]) => {
    persist({ ...overrides, blockOrders: { ...overrides.blockOrders, [sectionId]: ids } });
  }, [overrides, persist]);

  const getText = useCallback((key: string, fallback: string) => {
    return overrides.text[key] ?? fallback;
  }, [overrides.text]);

  const setText = useCallback((key: string, value: string) => {
    persist({ ...overrides, text: { ...overrides.text, [key]: value } });
  }, [overrides, persist]);

  const getStyle = useCallback((key: string): TextStyle => {
    return overrides.styles[key] ?? {};
  }, [overrides.styles]);

  const setStyle = useCallback((key: string, style: TextStyle) => {
    persist({ ...overrides, styles: { ...overrides.styles, [key]: style } });
  }, [overrides, persist]);

  const resetAll = useCallback(() => {
    clearOverrides();
    setOverrides(defaultOverrides());
  }, []);

  return (
    <AdminContext.Provider value={{
      isAdmin, toggleAdmin, panelOpen, setPanelOpen,
      orderedTabs, setTabOrder, getTabLabel, setTabLabel,
      getSectionOrder, setSectionOrder,
      getBlockOrder, setBlockOrder,
      getText, setText, getStyle, setStyle,
      resetAll, overrides,
    }}>
      {children}
    </AdminContext.Provider>
  );
}

export function useAdmin() {
  const ctx = useContext(AdminContext);
  if (!ctx) throw new Error("useAdmin must be used inside AdminProvider");
  return ctx;
}
