// ─── Theme Engine ─────────────────────────────────────────────────────────────
// Six cohesive palettes — some dark, some light, some vibrant.
// On every fresh page load the ThemeProvider randomly selects one and
// applies it by setting CSS custom properties on <html>.

export interface Theme {
  id: string;
  name: string;
  mode: "light" | "dark";
  // Accent hex used for JS-side tinting (e.g. Spline background tint)
  accentHex: string;
  vars: Record<string, string>;
}

// ─── Palette Definitions ──────────────────────────────────────────────────────

export const themes: Theme[] = [
  // 1. Arctic Light — clean white + electric blue
  {
    id: "arctic-light",
    name: "Arctic Light",
    mode: "light",
    accentHex: "#2563EB",
    vars: {
      "--background": "#FAFAFA",
      "--foreground": "#09090B",
      "--card": "#FFFFFF",
      "--card-foreground": "#09090B",
      "--popover": "#FFFFFF",
      "--popover-foreground": "#09090B",
      "--primary": "#18181B",
      "--primary-foreground": "#FAFAFA",
      "--secondary": "#F4F4F5",
      "--secondary-foreground": "#18181B",
      "--muted": "#F4F4F5",
      "--muted-foreground": "#71717A",
      "--accent": "#2563EB",
      "--accent-foreground": "#FFFFFF",
      "--border": "#E4E4E7",
      "--input": "#E4E4E7",
      "--ring": "#2563EB",
      "--radius": "0.625rem",
    },
  },

  // 2. Terminal Dark — near-black + neon green (coder aesthetic)
  {
    id: "terminal-dark",
    name: "Terminal Dark",
    mode: "dark",
    accentHex: "#22C55E",
    vars: {
      "--background": "#020617",
      "--foreground": "#F8FAFC",
      "--card": "#0E1223",
      "--card-foreground": "#F8FAFC",
      "--popover": "#0E1223",
      "--popover-foreground": "#F8FAFC",
      "--primary": "#22C55E",
      "--primary-foreground": "#020617",
      "--secondary": "#1E293B",
      "--secondary-foreground": "#F8FAFC",
      "--muted": "#1A1E2F",
      "--muted-foreground": "#94A3B8",
      "--accent": "#22C55E",
      "--accent-foreground": "#020617",
      "--border": "#334155",
      "--input": "#1E293B",
      "--ring": "#22C55E",
      "--radius": "0.375rem",
    },
  },

  // 3. Deep Space — dark navy + warm orange
  {
    id: "deep-space",
    name: "Deep Space",
    mode: "dark",
    accentHex: "#F97316",
    vars: {
      "--background": "#0F0F23",
      "--foreground": "#F8FAFC",
      "--card": "#1B1B30",
      "--card-foreground": "#F8FAFC",
      "--popover": "#1B1B30",
      "--popover-foreground": "#F8FAFC",
      "--primary": "#F97316",
      "--primary-foreground": "#0F172A",
      "--secondary": "#312E81",
      "--secondary-foreground": "#FFFFFF",
      "--muted": "#27273B",
      "--muted-foreground": "#94A3B8",
      "--accent": "#F97316",
      "--accent-foreground": "#0F172A",
      "--border": "#4338CA",
      "--input": "#27273B",
      "--ring": "#F97316",
      "--radius": "0.5rem",
    },
  },

  // 4. Ivory Editorial — warm cream + terracotta
  {
    id: "ivory-editorial",
    name: "Ivory Editorial",
    mode: "light",
    accentHex: "#EA580C",
    vars: {
      "--background": "#FAF7F2",
      "--foreground": "#1C1917",
      "--card": "#FFFFFF",
      "--card-foreground": "#1C1917",
      "--popover": "#FFFFFF",
      "--popover-foreground": "#1C1917",
      "--primary": "#9A3412",
      "--primary-foreground": "#FFFFFF",
      "--secondary": "#F5F0E8",
      "--secondary-foreground": "#1C1917",
      "--muted": "#F0EBE1",
      "--muted-foreground": "#78716C",
      "--accent": "#EA580C",
      "--accent-foreground": "#FFFFFF",
      "--border": "#E7E0D5",
      "--input": "#E7E0D5",
      "--ring": "#EA580C",
      "--radius": "0.75rem",
    },
  },

  // 5. Void Purple — deep purple bg + hot pink accent
  {
    id: "void-purple",
    name: "Void Purple",
    mode: "dark",
    accentHex: "#EC4899",
    vars: {
      "--background": "#0D0B14",
      "--foreground": "#F8FAFC",
      "--card": "#18142A",
      "--card-foreground": "#F8FAFC",
      "--popover": "#18142A",
      "--popover-foreground": "#F8FAFC",
      "--primary": "#A855F7",
      "--primary-foreground": "#0D0B14",
      "--secondary": "#2D1F4E",
      "--secondary-foreground": "#F8FAFC",
      "--muted": "#1E1632",
      "--muted-foreground": "#A78BFA",
      "--accent": "#EC4899",
      "--accent-foreground": "#FFFFFF",
      "--border": "#4C1D95",
      "--input": "#2D1F4E",
      "--ring": "#A855F7",
      "--radius": "0.5rem",
    },
  },

  // 6. Spotlight Gold — dramatic dark + gold
  {
    id: "spotlight-gold",
    name: "Spotlight Gold",
    mode: "dark",
    accentHex: "#EAB308",
    vars: {
      "--background": "#0C0C0E",
      "--foreground": "#FAF8F4",
      "--card": "#1A1810",
      "--card-foreground": "#FAF8F4",
      "--popover": "#1A1810",
      "--popover-foreground": "#FAF8F4",
      "--primary": "#CA8A04",
      "--primary-foreground": "#0C0C0E",
      "--secondary": "#1E1B10",
      "--secondary-foreground": "#FAF8F4",
      "--muted": "#1F1C0F",
      "--muted-foreground": "#A8956A",
      "--accent": "#EAB308",
      "--accent-foreground": "#0C0C0E",
      "--border": "#3D3520",
      "--input": "#1E1B10",
      "--ring": "#CA8A04",
      "--radius": "0.5rem",
    },
  },
];

// ─── Picker ───────────────────────────────────────────────────────────────────
// Called once at app boot — result is stable for the lifetime of the session.

export function pickRandomTheme(): Theme {
  return themes[Math.floor(Math.random() * themes.length)];
}

// ─── Applier ──────────────────────────────────────────────────────────────────

export function applyTheme(theme: Theme): void {
  const root = document.documentElement;
  Object.entries(theme.vars).forEach(([key, value]) => {
    root.style.setProperty(key, value);
  });
  root.setAttribute("data-theme", theme.id);
  root.setAttribute("data-mode", theme.mode);
  // Keep Tailwind dark-mode class in sync
  root.classList.toggle("dark", theme.mode === "dark");
}
