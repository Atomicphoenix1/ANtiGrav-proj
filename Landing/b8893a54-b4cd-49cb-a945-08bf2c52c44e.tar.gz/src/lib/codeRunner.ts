// ─── Code Runner (Simulated Server-Side Execution) ───────────────────────────
// Execution logic never ships to the client bundle. This module returns
// pre-crafted, realistic mock output after a simulated async delay,
// mimicking a real API call to a secure backend endpoint.

export interface ExecutionResult {
  output: string;
  success: boolean;
  durationMs: number;
}

const MOCK_OUTPUTS: Record<string, Omit<ExecutionResult, "durationMs">> = {
  "transcription-pipeline": {
    success: true,
    output: `[Pipeline] Initialized…
[Pipeline] Audio source validated ✓
[Pipeline] Transcription complete — 847 words
[Pipeline] Formatting to DOCX…
[Pipeline] Dispatching to Telegram channel ✓

Status  : SUCCESS
Duration: 5.2 s
Words   : 847`,
  },
  "scheduling-automation": {
    success: true,
    output: `[Scheduler] Loading 23 participant responses…
[Scheduler] Building availability density map…
[Scheduler] Running slot optimization…

TOP 4 OPTIMAL SLOTS:
  1. Mon 10:00–11:00 → 19 participants (82%)
  2. Wed 14:00–15:00 → 17 participants (73%)
  3. Thu 09:00–10:00 → 15 participants (65%)
  4. Fri 11:00–12:00 → 14 participants (60%)

Optimization complete in 0.08 s  (prev: 45 min manual)`,
  },
  "computational-chemistry": {
    success: true,
    output: `Gaussian 16 Rev. C.01 — Job Summary
=====================================
Molecule  : AgNP cluster (147 atoms)
Method    : DFT/B3LYP/LANL2DZ
Solvation : PCM (water)

Energy (SCF)  : -12847.3921 Hartree
Dipole moment : 0.0023 Debye
HOMO-LUMO gap : 2.87 eV

Output → output/agnp_147_results.log
Status  : Converged in 42 cycles ✓`,
  },
};

/**
 * Simulates a secure server-side code execution request.
 * Real algorithmic logic runs server-side; this function returns
 * sanitized output as if received from an authenticated API endpoint.
 */
export async function simulateExecution(projectId: string): Promise<ExecutionResult> {
  const start = Date.now();
  // Mimic realistic network + processing latency
  const delay = 1000 + Math.random() * 1200;
  await new Promise<void>((resolve) => setTimeout(resolve, delay));

  const result = MOCK_OUTPUTS[projectId] ?? {
    success: true,
    output: "Execution complete.",
  };

  return { ...result, durationMs: Date.now() - start };
}
