// ─── Audio Manager ────────────────────────────────────────────────────────────
// Singleton that enforces the "one track at a time" rule.
// React components subscribe via useAudioManager() hook.

import { useEffect, useState } from "react";

type TrackId = "welcome" | string; // project IDs are plain strings

interface AudioState {
  muted: boolean;
  playingId: TrackId | null;
}

class AudioManager {
  private tracks = new Map<TrackId, HTMLAudioElement>();
  private state: AudioState = { muted: false, playingId: null };
  private listeners = new Set<(s: AudioState) => void>();

  // ── Internal ────────────────────────────────────────────────────────────────

  private notify() {
    const snap = { ...this.state };
    this.listeners.forEach((fn) => fn(snap));
  }

  private getOrCreate(id: TrackId, src: string): HTMLAudioElement {
    if (!this.tracks.has(id)) {
      const el = new Audio(src);
      el.preload = "none";
      el.addEventListener("ended", () => {
        if (this.state.playingId === id) {
          this.state = { ...this.state, playingId: null };
          this.notify();
        }
      });
      this.tracks.set(id, el);
    }
    return this.tracks.get(id)!;
  }

  private pauseAll(except?: TrackId) {
    this.tracks.forEach((el, id) => {
      if (id !== except && !el.paused) {
        el.pause();
      }
    });
  }

  // ── Public API ───────────────────────────────────────────────────────────────

  subscribe(fn: (s: AudioState) => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  getState(): AudioState {
    return { ...this.state };
  }

  toggleMute() {
    this.state = { ...this.state, muted: !this.state.muted };
    this.tracks.forEach((el) => {
      el.muted = this.state.muted;
    });
    this.notify();
  }

  /** Play any track by id+src, pausing everything else first */
  play(id: TrackId, src: string) {
    const el = this.getOrCreate(id, src);
    el.muted = this.state.muted;

    if (this.state.playingId === id) return; // already playing

    this.pauseAll(id);
    this.state = { ...this.state, playingId: id };
    this.notify();

    el.play().catch(() => {
      // Browser autoplay policy — silently handle
      this.state = { ...this.state, playingId: null };
      this.notify();
    });
  }

  pause(id: TrackId) {
    const el = this.tracks.get(id);
    if (el && !el.paused) {
      el.pause();
    }
    if (this.state.playingId === id) {
      this.state = { ...this.state, playingId: null };
      this.notify();
    }
  }

  toggle(id: TrackId, src: string) {
    if (this.state.playingId === id) {
      this.pause(id);
    } else {
      this.play(id, src);
    }
  }

  destroy() {
    this.tracks.forEach((el) => {
      el.pause();
      el.src = "";
    });
    this.tracks.clear();
    this.listeners.clear();
  }
}

// ─── Singleton ────────────────────────────────────────────────────────────────
// advanced-init-once: created once at module level, never re-created.

export const audioManager = new AudioManager();

// ─── React Hook ───────────────────────────────────────────────────────────────

export function useAudioManager() {
  const [state, setState] = useState<AudioState>(() => audioManager.getState());

  useEffect(() => {
    return audioManager.subscribe(setState);
  }, []);

  return state;
}
